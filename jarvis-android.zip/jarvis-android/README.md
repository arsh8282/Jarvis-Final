# JARVIS - Android personal AI assistant (Python / Kivy)

Text + voice assistant with a futuristic UI, Gemini integration behind a provider abstraction, local history and
opt-in memory, an AI-assisted editor with diff/preview, a sandboxed developer workspace, and permission-aware Android
integrations. Builds to a debug APK with GitHub Actions (Buildozer + python-for-android).

## Verification status (read this first)

| Item | Status |
|---|---|
| Headless unit tests (59) | **Executed locally: all passed** (Python 3.12, `unittest`; pytest-compatible) |
| Workflow YAML syntax, `buildozer.spec` validation step, APK-locate step | **Executed locally** (parsed / run in isolation) |
| UI screen construction | Smoke-tested only against **stub Kivy classes** (no real rendering) |
| Real Kivy rendering, layout, animations | **Not verified** - needs `pip install kivy` / a device |
| APK build (`buildozer android debug`) | **Not run** - needs the Android SDK/NDK download; first verified when your GitHub Action runs |
| Gemini live calls, models list | **Not verified** - tested only with a fake HTTP transport |
| Speech-to-text / text-to-speech / intents / permissions on a phone | **Not verified** - need a physical device |
| Android 11+ package visibility for "launch app" and TTS | Known risk: may require `<queries>` manifest entries (not added) |

No APK exists yet. One appears only after the workflow succeeds on GitHub.

## Features

Screens: Home dashboard, Text chat, Voice, Editor, Developer workspace, Provider & model, Personality, Voice & language,
Memory & history, Android integrations (live permission status), Theme & accessibility, Diagnostics / privacy / about.

* **Text mode**: streaming, Stop, Retry, Regenerate, Edit last message, per-message select/copy/share, code-block copy/save,
  Markdown + light syntax highlighting, export, searchable history (rename/delete/export/clear).
* **Voice mode**: push-to-talk (default), listening/processing/speaking/interrupted/idle states, animated core + waveform,
  stop/repeat/return to text, rate/language/spoken-length settings, opt-in continuous listening with a visible `[REC]`
  indicator and a stop control. Shares conversation, settings and memory with text mode.
* **Provider layer**: `providers/base.py` interface, Gemini (REST, streaming, model listing, bounded retries only for
  429/5xx/network, key sent in a header never in a URL), offline Mock provider (default - works with no key).
* **Personality**: name, address form, formality, tone, length, languages, Hinglish for Smali, coding style, custom
  instructions, task profile. They are injected into every request *after* fixed rules that user text cannot override.
* **Editor**: select/copy/cut/paste, undo/redo, find/replace, AI actions (rewrite, grammar, translate, summarize, simplify,
  explain, bugs, refactor, patch) with **per-hunk diff review**; the original is untouched until Apply; Cancel/Restore.
* **Dev workspace**: sandboxed folder, browse/create/edit/rename/delete, text search, JSON/XML validation, automatic
  backups on overwrite/delete and one-tap restore, "Ask AI about this file".
* **Tools**: validated arguments, confirmation for consequential actions (setting) and destructive ones (always), honest
  results. The AI never executes code or tools by itself.
* **Messaging**: WhatsApp draft via `https://wa.me/` with recipient validation and confirmation. Reports "opened a draft",
  never "sent".

## Setup

```bash
git clone <your repo> && cd jarvis-android
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt      # kivy, plyer, certifi, pytest
python -m pytest -q                      # headless tests (no Kivy/API key needed)
python main.py                           # desktop preview (speech/Android features report "unavailable")
```

### Gemini key
Provider & Model screen -> choose `gemini`, paste your key (get one at Google AI Studio), **Save key**, **Test connection**,
optionally **Fetch available models**. The key is never in the repo, workflow, logs (redacted) or UI (masked).
*Limitation:* it lives in app-private storage (file mode 0600), not the hardware-backed Android Keystore.
`app_config.example.json` is a placeholder reference only; the app does not read it.

## GitHub & APK

1. Create a GitHub repo, then `git init && git add . && git commit -m "JARVIS" && git branch -M main && git remote add origin <url> && git push -u origin main`.
2. Open the repo's **Actions** tab and the **JARVIS Android Build** run (or **Run workflow** to start one manually).
3. When it succeeds, open the run page and scroll to **Artifacts**; download **jarvis-debug-apk** (a zip containing the `.apk`).
4. Unzip, copy the APK to your phone, allow "install unknown apps" for your file manager/browser, and install.

The first build downloads the SDK/NDK and compiles Kivy: expect 20-40 minutes; later builds use the cache.
Debug-signed only. For a release build add your own keystore through GitHub Secrets (never commit it).

### Toolchain (pinned; keep workflow, spec and this table in sync)
Python 3.11 - Java 17 - Buildozer 1.5.0 - Cython 0.29.36 - python-for-android (stable, bundled) - Kivy 2.3.0 - API 33 - NDK 25b - arm64-v8a.
Dependencies: `pyjnius`, `sqlite3`, `openssl` (p4a recipes); `plyer`, `certifi` (pure Python). KivyMD is intentionally not used (fewer packaging risks).

### Troubleshooting
* *Licenses/SDK errors*: `android.accept_sdk_license = True` is set; clear the cache (Actions -> Caches) and rerun.
* *Cython/`pkg_resources`/recipe compile errors*: confirm the pinned versions above; the log is uploaded as `buildozer-build-log` on failure.
* *No APK found*: the workflow fails with a clear message if `./bin` has no `.apk`.
* *HTTPS errors on device*: `certifi` must stay in `requirements`.
* *Speech silent/unavailable*: install/enable Google speech services; on Android 11+ TTS may need manifest `<queries>`.
* *API errors*: 401/403 bad key; 404 model id; 429 quota (auto-retried at most twice).

## Permissions
`INTERNET` (AI requests) and `RECORD_AUDIO` (push-to-talk). No storage permission: the workspace is app-private
(or a path you set that the app may write to). Android auto-backup is disabled.

## Known limitations (honest list)
* Cannot edit text inside other apps or control them. Use clipboard/share into the Editor and copy/share the result back.
* No "Share to JARVIS" target, no Storage Access Framework folder grants, and **no AccessibilityService** in this build
  (these need native code; see `android_bridge/README.md`). The Integrations screen only opens Accessibility settings.
* Launching other apps may fail on Android 11+ due to package-visibility rules; WhatsApp drafts use a URL intent which works without it.
* Speech quality/availability depend on the device's speech services.
* Generated code is never claimed to compile or pass tests.

## Privacy
Stored locally: settings, history, memories, workspace files, API key. Sent to your provider: current conversation (trimmed),
your instructions, enabled memories and text you ask the AI to process. Demo mode sends nothing. No background recording, screen
capture or app monitoring. Logging is off by default and redacts secrets.

## Architecture
```
main.py, app_context.py   entry + service wiring (headless-testable)
providers/   base, gemini, mock          settings/   defaults (typed fields), manager
assistant/   prompts, context, conversation, orchestrator
storage/     database, history, memory   security/   secrets (redaction), validation, permissions
editor/      diff, text_actions, workspace     tools/   registry, file_tools, android_tools, messaging
voice/       speech_input, speech_output       ui/      theme, components, forms, markup, screens/
tests/       59 headless tests          .github/workflows/  tests.yml, android-build.yml
```

## Add another AI provider
1. Create `providers/yourprovider.py` implementing `Provider` (`generate`, `stream`, optional `list_models`), mapping its errors to `ProviderError`.
2. Register it in `providers/__init__.py:create_provider` and add its name to the `provider` choices in `settings/defaults.py`.
3. Store its key via `SecretStore` under a new name and add a field to `ui/screens/settings_screens.py`.
4. Add tests with a fake transport (see `tests/test_providers.py`). Live tests must stay opt-in.

## Device test checklist (manual)
Mic permission flow - push-to-talk transcription - TTS speed/language - WhatsApp draft opens - Sharesheet - settings intents -
rotation layouts - large-font/high-contrast themes - key save/test with a real Gemini key.
