"""Wires all services together. No UI imports here, so it is testable headless."""
from __future__ import annotations

import logging
from pathlib import Path

from assistant.orchestrator import Orchestrator
from editor.workspace import Workspace
from security.secrets import RedactingFilter, SecretStore
from settings.manager import SettingsManager
from storage import Database, HistoryStore, MemoryStore
from tools import android_tools, file_tools, messaging
from tools.registry import ToolRegistry
from voice.speech_input import SpeechInput
from voice.speech_output import SpeechOutput


class AppContext:
    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.settings = SettingsManager(self.data_dir / "settings.json")
        self.secrets = SecretStore(self.data_dir / "secrets.json")
        self.db = Database(self.data_dir / "jarvis.db")
        self.history = HistoryStore(self.db)
        self.memory = MemoryStore(self.db, lambda: self.settings.get("memory_enabled"))
        self.log_path = self.data_dir / "jarvis.log"
        self._setup_logging()
        self.settings.subscribe(lambda k, v: self._setup_logging() if k == "diagnostic_logging" else None)
        self.workspace = self._make_workspace()
        self.platform = android_tools.AndroidPlatform()
        self.tools = ToolRegistry(lambda: self.settings.get("confirm_actions"))
        self.orch = Orchestrator(self.settings, self.history, self.memory, self.secrets)
        self.speech_in, self.speech_out = SpeechInput(), SpeechOutput()
        self._register_tools()
        self.settings.subscribe(self._on_setting)

    def _make_workspace(self) -> Workspace:
        custom = self.settings.get("workspace_dir")
        try:
            return Workspace(custom or self.data_dir / "workspace")
        except Exception:
            return Workspace(self.data_dir / "workspace")

    def _register_tools(self) -> None:
        self.tools._tools.clear()
        file_tools.register(self.tools, self.workspace)
        android_tools.register(self.tools, self.platform)
        messaging.register(self.tools, self.platform)

    def _on_setting(self, key, _value) -> None:
        if key == "workspace_dir":
            self.workspace = self._make_workspace()
            self._register_tools()
        elif key == "history_enabled":
            self.orch.new_conversation()

    def _setup_logging(self) -> None:
        root = logging.getLogger("jarvis")
        for h in list(root.handlers):
            root.removeHandler(h)
            h.close()
        root.setLevel(logging.INFO)
        if self.settings.get("diagnostic_logging"):
            fh = logging.FileHandler(self.log_path, encoding="utf-8")
            fh.addFilter(RedactingFilter())
            fh.setFormatter(logging.Formatter("%(asctime)s %(name)s %(levelname)s %(message)s"))
            root.addHandler(fh)
        else:
            root.addHandler(logging.NullHandler())

    def close(self) -> None:
        self.speech_out.shutdown()
        self.db.close()
