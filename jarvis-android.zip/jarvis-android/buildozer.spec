# JARVIS - Buildozer configuration.
# Pinned, mutually compatible toolchain (see README "Toolchain"):
#   Buildozer 1.5.0, Cython 0.29.36, python-for-android (stable, bundled with Buildozer),
#   Kivy 2.3.0, Android API 33, NDK 25b, Java 17.
[app]
title = JARVIS
package.name = jarvis
package.domain = org.jarvisassistant
source.dir = .
source.include_exts = py,png,jpg,json,ttf
source.exclude_dirs = tests, bin, .buildozer, .github, venv, .venv, __pycache__, android_bridge, .git
version = 1.0.0

# Every entry has an Android recipe or is pure Python:
#  kivy/pyjnius/sqlite3/openssl: python-for-android recipes; plyer, certifi: pure Python.
requirements = python3,kivy==2.3.0,pyjnius,android,plyer==2.1.0,certifi,sqlite3,openssl

orientation = portrait,landscape
fullscreen = 0

# Minimal permissions only. No storage permission: files live in the app-private workspace.
android.permissions = INTERNET,RECORD_AUDIO

android.api = 33
android.minapi = 24
android.ndk = 25b
android.ndk_api = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
# Secrets live in app-private storage; keep them out of Android auto-backup.
android.allow_backup = False
android.debug_artifact = apk

[buildozer]
log_level = 2
warn_on_root = 1
