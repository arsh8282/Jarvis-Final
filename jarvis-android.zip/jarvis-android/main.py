"""JARVIS entry point."""
from ui.app import JarvisApp

if __name__ == "__main__":
    JarvisApp().run()
