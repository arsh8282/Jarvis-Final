# Android bridge

This build uses **pyjnius** (Python -> Java reflection) for Intents, Settings screens, the Sharesheet and
TextToSpeech (`tools/android_tools.py`, `voice/speech_output.py`). No custom Java/Kotlin sources are compiled.

Not implemented (would need native code, see README "Known limitations"):
- An `AccessibilityService` (needs a Java service class + manifest entry via python-for-android `--add-source`).
- A "Process text"/Share target intent-filter so JARVIS appears in other apps' selection menus.
- Storage Access Framework directory-tree grants (`ACTION_OPEN_DOCUMENT_TREE`).

If you add them, place Java sources here and reference them with `android.add_src` in `buildozer.spec`.
