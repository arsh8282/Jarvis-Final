"""Persistent settings store (JSON, atomic writes). Secrets are NOT stored here."""
from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

from .defaults import DEFAULTS, FIELDS, validate_value


class SettingsManager:
    def __init__(self, path):
        self.path = Path(path)
        self._values: dict[str, Any] = dict(DEFAULTS)
        self._listeners: list[Callable[[str, Any], None]] = []
        self._lock = threading.RLock()
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("not an object")
        except (OSError, ValueError):
            try:
                self.path.rename(self.path.with_suffix(".corrupt"))
            except OSError:
                pass
            return
        for k, v in data.items():
            if k in FIELDS:
                try:
                    self._values[k] = validate_value(k, v)
                except ValueError:
                    pass  # keep default for invalid persisted value

    def get(self, key: str) -> Any:
        return self._values[key]

    def snapshot(self) -> dict:
        return dict(self._values)

    def set(self, key: str, value: Any) -> None:
        v = validate_value(key, value)
        with self._lock:
            self._values[key] = v
            self._save()
        for cb in list(self._listeners):
            cb(key, v)

    def reset(self, keys: Optional[Iterable[str]] = None) -> None:
        for k in list(keys) if keys is not None else list(DEFAULTS):
            self.set(k, DEFAULTS[k])

    def subscribe(self, cb: Callable[[str, Any], None]) -> None:
        self._listeners.append(cb)

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._values, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.path)
