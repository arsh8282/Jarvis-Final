"""Typed, validated setting definitions. Every key here is consumed at runtime (see README)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import re


@dataclass(frozen=True)
class Field:
    default: Any
    kind: str  # str | text | bool | choice | float | int
    label: str
    choices: tuple = ()
    lo: float | None = None
    hi: float | None = None
    maxlen: int = 500


FIELDS: dict[str, Field] = {
    # provider
    "provider": Field("mock", "choice", "AI provider", ("mock", "gemini")),
    "model": Field("gemini-2.5-flash", "str", "Model id", maxlen=100),
    "temperature": Field(0.7, "float", "Temperature", lo=0.0, hi=2.0),
    "max_output_tokens": Field(2048, "int", "Max output tokens", lo=16, hi=65536),
    # personality
    "assistant_name": Field("JARVIS", "str", "Assistant name", maxlen=40),
    "formality": Field("formal", "choice", "Formality", ("casual", "balanced", "formal")),
    "address_as": Field("Sir", "str", "Address me as", maxlen=40),
    "custom_instructions": Field("", "text", "Custom instructions", maxlen=2000),
    "response_length": Field("balanced", "choice", "Response length", ("brief", "balanced", "detailed")),
    "tone": Field("composed", "choice", "Tone", ("composed", "friendly", "technical", "witty")),
    "language": Field("English", "str", "Preferred language", maxlen=40),
    "code_language": Field("English", "str", "Code explanation language", maxlen=40),
    "hinglish_smali": Field(False, "bool", "Explain Smali/modding in simple Hinglish"),
    "coding_style": Field("", "text", "Coding style & formatting", maxlen=500),
    "task_profile": Field("general", "choice", "Default task profile", ("general", "coding", "writing", "modding")),
    "confirm_actions": Field(True, "bool", "Confirm consequential actions"),
    # modes & voice
    "default_mode": Field("text", "choice", "Default mode", ("text", "voice")),
    "speak_responses": Field(True, "bool", "Speak responses in voice mode"),
    "spoken_length": Field("short", "choice", "Spoken response length", ("short", "medium", "full")),
    "voice_rate": Field(1.0, "float", "Speech rate", lo=0.5, hi=2.0),
    "voice_language": Field("en-US", "str", "Voice / recognition language tag", maxlen=15),
    "continuous_listening": Field(False, "bool", "Allow continuous listening (opt-in)"),
    # appearance
    "theme": Field("dark", "choice", "Theme", ("dark", "light")),
    "font_scale": Field(1.0, "float", "Text size", lo=0.8, hi=1.6),
    "high_contrast": Field(False, "bool", "High contrast"),
    # data & privacy
    "history_enabled": Field(True, "bool", "Save chat history locally"),
    "memory_enabled": Field(False, "bool", "Enable persistent memory"),
    "workspace_dir": Field("", "str", "Workspace directory", maxlen=300),
    "diagnostic_logging": Field(False, "bool", "Write diagnostic log file"),
}
DEFAULTS = {k: f.default for k, f in FIELDS.items()}
_CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")


def validate_value(key: str, value: Any) -> Any:
    if key not in FIELDS:
        raise ValueError(f"Unknown setting: {key}")
    f = FIELDS[key]
    if f.kind == "bool":
        if not isinstance(value, bool):
            raise ValueError(f"{f.label}: must be true or false")
        return value
    if f.kind in ("int", "float"):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"{f.label}: must be a number")
        v = int(value) if f.kind == "int" else float(value)
        if f.kind == "int" and v != value:
            raise ValueError(f"{f.label}: must be a whole number")
        if (f.lo is not None and v < f.lo) or (f.hi is not None and v > f.hi):
            raise ValueError(f"{f.label}: must be between {f.lo} and {f.hi}")
        return v
    if f.kind == "choice":
        if value not in f.choices:
            raise ValueError(f"{f.label}: must be one of {', '.join(f.choices)}")
        return value
    if not isinstance(value, str):
        raise ValueError(f"{f.label}: must be text")
    v = value.strip()
    if len(v) > f.maxlen:
        raise ValueError(f"{f.label}: too long (max {f.maxlen} characters)")
    if _CTRL.search(v):
        raise ValueError(f"{f.label}: contains control characters")
    if f.kind == "str" and "\n" in v:
        raise ValueError(f"{f.label}: must be a single line")
    return v
