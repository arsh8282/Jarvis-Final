from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from . import diff

AI_ACTIONS = {
    "Rewrite": "Rewrite the text to read better. Keep the meaning.",
    "Fix grammar": "Correct grammar, spelling and punctuation. Change nothing else.",
    "Translate": "Translate the text into {arg}.",
    "Summarize": "Summarize the text concisely.",
    "Simplify": "Rewrite the text in simpler language.",
    "Improve": "Improve clarity and style.",
    "Explain code": "Explain what this code does, step by step.",
    "Find bugs": "Identify likely bugs and risky code. Do not claim to have run it.",
    "Refactor": "Refactor this code for readability, keeping behaviour. Return only the revised code.",
    "Generate patch": "Return a corrected version of this code. Return only the revised code.",
}
REPLACING = {"Rewrite", "Fix grammar", "Translate", "Simplify", "Improve", "Refactor", "Generate patch"}


def build_prompt(action: str, text: str, arg: str = "") -> str:
    if action not in AI_ACTIONS:
        raise ValueError(f"Unknown action: {action}")
    instr = AI_ACTIONS[action].format(arg=arg or "English")
    tail = "\nReturn only the resulting text, without commentary or code fences." if action in REPLACING else ""
    return f"{instr}{tail}\n\n---\n{text}\n---"


def strip_fences(reply: str) -> str:
    s = reply.strip()
    if s.startswith("```") and s.endswith("```") and s.count("```") == 2:
        s = s.split("\n", 1)[1] if "\n" in s else ""
        s = s[:-3]
    return s.rstrip("\n") if not reply.endswith("\n") else s


class TextDocument:
    """Editable text with undo/redo, find and replace. Selection is a (start, end) range."""

    def __init__(self, text: str = ""):
        self.text = text
        self._undo: list[str] = []
        self._redo: list[str] = []

    def set_text(self, text: str) -> None:
        if text != self.text:
            self._undo.append(self.text)
            self._redo.clear()
            self.text = text

    def replace_range(self, start: int, end: int, new: str) -> None:
        if not (0 <= start <= end <= len(self.text)):
            raise ValueError("Invalid selection range.")
        self.set_text(self.text[:start] + new + self.text[end:])

    def undo(self) -> bool:
        if not self._undo:
            return False
        self._redo.append(self.text)
        self.text = self._undo.pop()
        return True

    def redo(self) -> bool:
        if not self._redo:
            return False
        self._undo.append(self.text)
        self.text = self._redo.pop()
        return True

    def find_all(self, needle: str, case: bool = False) -> list[int]:
        if not needle:
            return []
        hay, n = (self.text, needle) if case else (self.text.lower(), needle.lower())
        out, i = [], hay.find(n)
        while i != -1:
            out.append(i)
            i = hay.find(n, i + max(1, len(n)))
        return out

    def replace_all(self, needle: str, repl: str, case: bool = False) -> int:
        hits = self.find_all(needle, case)
        if not hits:
            return 0
        out, pos = [], 0
        for h in hits:
            out += [self.text[pos:h], repl]
            pos = h + len(needle)
        out.append(self.text[pos:])
        self.set_text("".join(out))
        return len(hits)


@dataclass
class ChangeReview:
    """A proposed AI change. The original is preserved until apply() is called by the user."""
    original: str
    proposed: str
    start: Optional[int] = None  # selection range replaced, if any
    end: Optional[int] = None

    def diff_text(self) -> str:
        return diff.unified(self.original, self.proposed)

    def hunk_count(self) -> int:
        return len(diff.hunks(self.original, self.proposed))

    def result(self, selected=None) -> str:
        sel = range(self.hunk_count()) if selected is None else selected
        return diff.apply_hunks(self.original, self.proposed, sel)
