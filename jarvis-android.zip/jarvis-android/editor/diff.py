from __future__ import annotations

import difflib
from typing import Iterable


def unified(a: str, b: str, name: str = "text") -> str:
    return "".join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), f"a/{name}", f"b/{name}"))


def hunks(a: str, b: str) -> list[tuple[int, int, int, int]]:
    """Non-equal opcode ranges (i1,i2,j1,j2) between line lists of a and b."""
    sm = difflib.SequenceMatcher(None, a.splitlines(True), b.splitlines(True), autojunk=False)
    return [(i1, i2, j1, j2) for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag != "equal"]


def apply_hunks(a: str, b: str, selected: Iterable[int]) -> str:
    """Apply only the chosen hunks of a->b to a. Unselected hunks keep the original text."""
    sel = set(selected)
    al, bl = a.splitlines(True), b.splitlines(True)
    out: list[str] = []
    pos = 0
    for idx, (i1, i2, j1, j2) in enumerate(hunks(a, b)):
        out += al[pos:i1]
        out += bl[j1:j2] if idx in sel else al[i1:i2]
        pos = i2
    out += al[pos:]
    return "".join(out)


def describe_hunk(a: str, b: str, idx: int, limit: int = 160) -> str:
    i1, i2, j1, j2 = hunks(a, b)[idx]
    al, bl = a.splitlines(True), b.splitlines(True)
    old, new = "".join(al[i1:i2]).strip(), "".join(bl[j1:j2]).strip()
    return f"- {old[:limit] or '(nothing)'}\n+ {new[:limit] or '(nothing)'}"
