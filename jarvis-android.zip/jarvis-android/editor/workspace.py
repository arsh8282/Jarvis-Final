"""Authorized workspace: sandboxed file operations with backups. All paths are workspace-relative."""
from __future__ import annotations

import shutil
import time
from pathlib import Path

from security.validation import ValidationError, safe_resolve

from . import diff

BACKUP_DIR = ".jarvis_backups"


class WorkspaceError(Exception):
    pass


class Workspace:
    MAX_READ = 1_000_000  # bytes

    def __init__(self, root):
        self.root = Path(root)
        try:
            self.root.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise WorkspaceError(f"Cannot use workspace: {e.strerror}") from e
        self.root = self.root.resolve()
        self.backup_root = self.root / BACKUP_DIR

    def resolve(self, rel: str) -> Path:
        try:
            p = safe_resolve(self.root, rel)
        except ValidationError as e:
            raise WorkspaceError(str(e)) from None
        if p == self.backup_root or self.backup_root in p.parents:
            raise WorkspaceError("The backup area is managed by JARVIS and cannot be accessed directly.")
        return p

    def rel(self, p: Path) -> str:
        return p.relative_to(self.root).as_posix()

    def list_dir(self, rel: str = "") -> list[dict]:
        d = self.resolve(rel) if rel else self.root
        if not d.is_dir():
            raise WorkspaceError("Not a directory.")
        out = []
        for c in sorted(d.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            if c.name == BACKUP_DIR:
                continue
            out.append({"name": c.name, "path": self.rel(c), "dir": c.is_dir(),
                        "size": c.stat().st_size if c.is_file() else 0})
        return out

    def read_text(self, rel: str) -> str:
        p = self.resolve(rel)
        try:
            if not p.is_file():
                raise WorkspaceError("File not found.")
            if p.stat().st_size > self.MAX_READ:
                raise WorkspaceError(f"File too large to open (limit {self.MAX_READ // 1000} KB).")
            return p.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            raise WorkspaceError("File is not UTF-8 text.") from None
        except OSError as e:
            raise WorkspaceError(f"Cannot read file: {e.strerror}") from e

    def preview_write(self, rel: str, new: str) -> str:
        old = self.read_text(rel) if self.resolve(rel).exists() else ""
        return diff.unified(old, new, rel)

    def _backup(self, p: Path) -> Path:
        rel = self.rel(p).replace("/", "__")
        stamp = time.strftime("%Y%m%dT%H%M%S") + f"{int((time.time() % 1) * 1e6):06d}"
        dest = self.backup_root / f"{rel}.{stamp}.bak"
        self.backup_root.mkdir(exist_ok=True)
        shutil.copy2(p, dest)
        return dest

    def write_text(self, rel: str, content: str, overwrite: bool = True) -> dict:
        p = self.resolve(rel)
        try:
            existed = p.exists()
            if existed and not overwrite:
                raise WorkspaceError("File already exists.")
            if existed and p.is_dir():
                raise WorkspaceError("Path is a directory.")
            backup = self._backup(p) if existed else None
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
        except OSError as e:
            raise WorkspaceError(f"Cannot write file: {e.strerror}") from e
        return {"path": self.rel(p), "backup": backup.name if backup else None}

    def rename(self, src: str, dst: str) -> str:
        a, b = self.resolve(src), self.resolve(dst)
        if not a.exists():
            raise WorkspaceError("Source does not exist.")
        if b.exists():
            raise WorkspaceError("Destination already exists; nothing was changed.")
        try:
            b.parent.mkdir(parents=True, exist_ok=True)
            a.rename(b)
        except OSError as e:
            raise WorkspaceError(f"Cannot rename: {e.strerror}") from e
        return self.rel(b)

    def delete(self, rel: str) -> str:
        """Recoverable delete: moves the file into the backup area."""
        p = self.resolve(rel)
        if not p.is_file():
            raise WorkspaceError("Only files can be deleted (not found or is a directory).")
        try:
            b = self._backup(p)
            p.unlink()
        except OSError as e:
            raise WorkspaceError(f"Cannot delete: {e.strerror}") from e
        return b.name

    def list_backups(self, rel: str) -> list[str]:
        prefix = self.rel(self.resolve(rel)).replace("/", "__") + "."
        if not self.backup_root.exists():
            return []
        return sorted(x.name for x in self.backup_root.iterdir() if x.name.startswith(prefix) and x.name.endswith(".bak"))

    def restore(self, rel: str, backup_name: str) -> str:
        if backup_name not in self.list_backups(rel):
            raise WorkspaceError("Backup not found for this file.")
        p = self.resolve(rel)
        try:
            if p.exists():
                self._backup(p)  # restoring never loses the current version
            p.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(self.backup_root / backup_name, p)
        except OSError as e:
            raise WorkspaceError(f"Cannot restore: {e.strerror}") from e
        return self.rel(p)

    def search(self, query: str, max_results: int = 50) -> list[dict]:
        if not query:
            return []
        q, out = query.lower(), []
        for p in sorted(self.root.rglob("*")):
            if len(out) >= max_results:
                break
            if not p.is_file() or BACKUP_DIR in p.parts or p.stat().st_size > self.MAX_READ:
                continue
            try:
                for n, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
                    if q in line.lower():
                        out.append({"path": self.rel(p), "line": n, "text": line.strip()[:200]})
                        if len(out) >= max_results:
                            break
            except (UnicodeDecodeError, OSError):
                continue
        return out
