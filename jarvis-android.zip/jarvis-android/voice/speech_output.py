"""Text-to-speech via Android TextToSpeech (pyjnius). Unavailable off-device."""
from __future__ import annotations

import os
import re


def to_spoken(text: str, length: str = "short") -> str:
    """Strip markdown/code so speech is clean, then shorten per setting."""
    t = re.sub(r"```.*?```", " (code omitted) ", text, flags=re.S)
    t = re.sub(r"`([^`]*)`", r"\1", t)
    t = re.sub(r"[*_#>]+", "", t)
    t = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", t)
    t = re.sub(r"\s+", " ", t).strip()
    if length == "full":
        return t
    sentences = re.split(r"(?<=[.!?])\s+", t)
    n = 2 if length == "short" else 5
    return " ".join(sentences[:n])


class SpeechOutput:
    def __init__(self):
        self.available = False
        self.reason = "Text-to-speech needs an Android device."
        self._tts = None
        self._ready = False
        if "ANDROID_ARGUMENT" in os.environ:
            self._init_android()

    def _init_android(self):
        try:
            from jnius import PythonJavaClass, autoclass, java_method  # type: ignore

            outer = self

            class _Init(PythonJavaClass):
                __javainterfaces__ = ["android/speech/tts/TextToSpeech$OnInitListener"]
                __javacontext__ = "app"

                @java_method("(I)V")
                def onInit(self, status):
                    outer._ready = status == 0
                    if not outer._ready:
                        outer.reason = "Android TTS engine failed to initialise."

            act = autoclass("org.kivy.android.PythonActivity").mActivity
            self._listener = _Init()
            self._tts = autoclass("android.speech.tts.TextToSpeech")(act, self._listener)
            self.available = True
            self.reason = ""
        except Exception as e:
            self.reason = f"TTS unavailable: {e}"

    def speak(self, text: str, rate: float = 1.0, lang_tag: str = "en-US") -> bool:
        if not (self.available and self._ready and text):
            return False
        try:
            from jnius import autoclass  # type: ignore
            Locale = autoclass("java.util.Locale")
            self._tts.setLanguage(Locale.forLanguageTag(lang_tag))
            self._tts.setSpeechRate(float(rate))
            self._tts.speak(text, 0, None, "jarvis")  # QUEUE_FLUSH
            return True
        except Exception as e:
            self.reason = f"TTS error: {e}"
            return False

    def stop(self) -> None:
        if self._tts is not None:
            try:
                self._tts.stop()
            except Exception:
                pass

    def is_speaking(self) -> bool:
        try:
            return bool(self._tts.isSpeaking()) if self._tts is not None else False
        except Exception:
            return False

    def shutdown(self) -> None:
        if self._tts is not None:
            try:
                self._tts.shutdown()
            except Exception:
                pass
