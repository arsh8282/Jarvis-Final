"""Speech-to-text via plyer's Android SpeechRecognizer wrapper (push-to-talk)."""
from __future__ import annotations

import os

from security import permissions


class SpeechInput:
    def __init__(self):
        self.on_android = "ANDROID_ARGUMENT" in os.environ
        self._stt = None
        self.reason = "Speech recognition needs an Android device."
        if self.on_android:
            try:
                from plyer import stt  # type: ignore
                self._stt = stt
                self.reason = ""
            except Exception as e:
                self.reason = f"Speech recognition unavailable: {e}"

    @property
    def available(self) -> bool:
        return self._stt is not None

    def start(self, lang_tag: str = "en-US") -> str:
        """Return '' on success or a user-readable error."""
        if not self.available:
            return self.reason
        if permissions.check("RECORD_AUDIO") != "granted":
            permissions.request(["RECORD_AUDIO"])
            return "Microphone permission is required. Grant it, then try again."
        try:
            self._stt.language = lang_tag
            self._stt.start()
            return ""
        except Exception as e:
            return f"Could not start listening: {e}"

    def stop(self) -> None:
        try:
            if self._stt is not None:
                self._stt.stop()
        except Exception:
            pass

    def poll(self) -> tuple[str, str]:
        """(transcript, error) - read after stop(); either may be empty."""
        if self._stt is None:
            return "", self.reason
        try:
            res = list(getattr(self._stt, "results", []) or [])
            err = getattr(self._stt, "errors", []) or []
            return (res[0] if res else ""), (str(err[-1]) if err and not res else "")
        except Exception as e:
            return "", str(e)
