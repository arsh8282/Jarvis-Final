"""Design tokens. Call apply(settings) before building screens."""
from __future__ import annotations

PALETTES = {
    "dark": dict(bg=(0.02, 0.04, 0.07, 1), surface=(0.06, 0.09, 0.14, 1), surface2=(0.09, 0.13, 0.2, 1),
                 accent=(0.0, 0.85, 0.95, 1), accent2=(0.0, 0.6, 0.62, 1), text=(0.88, 0.95, 0.98, 1),
                 muted=(0.55, 0.65, 0.72, 1), danger=(1.0, 0.35, 0.4, 1), ok=(0.3, 0.9, 0.6, 1)),
    "light": dict(bg=(0.94, 0.97, 0.99, 1), surface=(1, 1, 1, 1), surface2=(0.88, 0.94, 0.97, 1),
                  accent=(0.0, 0.5, 0.62, 1), accent2=(0.0, 0.38, 0.45, 1), text=(0.05, 0.1, 0.14, 1),
                  muted=(0.3, 0.38, 0.44, 1), danger=(0.75, 0.1, 0.15, 1), ok=(0.05, 0.5, 0.3, 1)),
}


class Theme:
    def __init__(self):
        self.scale = 1.0
        self.set("dark", False, 1.0)

    def set(self, name: str, high_contrast: bool, scale: float) -> None:
        p = dict(PALETTES[name])
        if high_contrast:
            p["text"] = (1, 1, 1, 1) if name == "dark" else (0, 0, 0, 1)
            p["muted"] = p["text"]
            p["bg"] = (0, 0, 0, 1) if name == "dark" else (1, 1, 1, 1)
        self.__dict__.update(p)
        self.name, self.scale = name, scale

    def apply(self, settings) -> None:
        self.set(settings.get("theme"), settings.get("high_contrast"), settings.get("font_scale"))

    def fs(self, base: float) -> float:
        from kivy.metrics import sp
        return sp(base * self.scale)


T = Theme()
