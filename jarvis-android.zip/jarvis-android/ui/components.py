"""Reusable widgets: neon buttons, cards, animated core, waveform, popups, background threads."""
from __future__ import annotations

import math
import random
import threading
from typing import Callable

from kivy.clock import Clock
from kivy.graphics import Color, Ellipse, Line, Rectangle, RoundedRectangle
from kivy.metrics import dp
from kivy.properties import NumericProperty, StringProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget

from .theme import T


def run_bg(work: Callable[[], object], done: Callable[[object, Exception | None], None]) -> threading.Thread:
    """Run `work` off the UI thread; `done(result, error)` is invoked on the UI thread."""
    def target():
        res, err = None, None
        try:
            res = work()
        except Exception as e:  # surfaced to UI, never swallowed
            err = e
        Clock.schedule_once(lambda dt: done(res, err))
    th = threading.Thread(target=target, daemon=True)
    th.start()
    return th


class WrapLabel(Label):
    def __init__(self, text="", size=15, color=None, bold=False, **kw):
        super().__init__(text=text, markup=True, color=color or T.text, font_size=T.fs(size), bold=bold,
                         halign="left", valign="top", size_hint_y=None, **kw)
        self.bind(width=lambda *_: setattr(self, "text_size", (self.width, None)),
                  texture_size=lambda *_: setattr(self, "height", self.texture_size[1] + dp(4)))


class NeonButton(Button):
    def __init__(self, text="", primary=True, danger=False, **kw):
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(48))  # >= 48dp touch target
        super().__init__(text=text, background_normal="", background_down="", background_color=(0, 0, 0, 0),
                         color=T.text, font_size=T.fs(14), **kw)
        self._c = T.danger if danger else (T.accent if primary else T.muted)
        with self.canvas.before:
            self._fill = Color(*self._c[:3], 0.18)
            self._rect = RoundedRectangle(radius=[dp(10)])
            self._edge = Color(*self._c)
            self._line = Line(width=dp(1.2))
        self.bind(pos=self._redraw, size=self._redraw, state=self._press)

    def _redraw(self, *_):
        self._rect.pos, self._rect.size = self.pos, self.size
        self._line.rounded_rectangle = (*self.pos, *self.size, dp(10))

    def _press(self, *_):
        self._fill.a = 0.45 if self.state == "down" else 0.18


class Card(BoxLayout):
    def __init__(self, **kw):
        kw.setdefault("orientation", "vertical")
        kw.setdefault("padding", dp(12))
        kw.setdefault("spacing", dp(8))
        kw.setdefault("size_hint_y", None)
        super().__init__(**kw)
        with self.canvas.before:
            Color(*T.surface)
            self._r = RoundedRectangle(radius=[dp(14)])
            Color(*T.accent2[:3], 0.5)
            self._l = Line(width=dp(1))
        self.bind(pos=self._u, size=self._u, minimum_height=self.setter("height"))

    def _u(self, *_):
        self._r.pos, self._r.size = self.pos, self.size
        self._l.rounded_rectangle = (*self.pos, *self.size, dp(14))


class Column(ScrollView):
    """Vertical scrolling column; add widgets to `.box`."""

    def __init__(self, **kw):
        super().__init__(do_scroll_x=False, **kw)
        self.box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=dp(12))
        self.box.bind(minimum_height=self.box.setter("height"))
        self.add_widget(self.box)

    def clear(self):
        self.box.clear_widgets()

    def add(self, w):
        self.box.add_widget(w)
        return w

    def to_bottom(self):
        Clock.schedule_once(lambda dt: setattr(self, "scroll_y", 0), 0.05)


def field(multiline=False, password=False, text="", hint="", height=None, **kw) -> TextInput:
    return TextInput(text=text, hint_text=hint, multiline=multiline, password=password, write_tab=False,
                     size_hint_y=None, height=height or dp(48), font_size=T.fs(15),
                     background_color=T.surface2, foreground_color=T.text, cursor_color=T.accent,
                     hint_text_color=T.muted, padding=[dp(10), dp(12)], **kw)


class CoreWidget(Widget):
    """Animated JARVIS core. state: idle | listening | processing | speaking | error."""
    state = StringProperty("idle")
    phase = NumericProperty(0)

    def __init__(self, **kw):
        super().__init__(**kw)
        self._ev = Clock.schedule_interval(self._tick, 1 / 30)
        self.bind(pos=self._draw, size=self._draw, state=self._draw)

    def _tick(self, dt):
        speed = {"idle": 0.6, "listening": 2.0, "processing": 3.5, "speaking": 2.6, "error": 0.3}[self.state]
        self.phase += dt * speed
        self._draw()

    def _draw(self, *_):
        self.canvas.clear()
        cx, cy = self.center
        r = min(self.width, self.height) / 2 * 0.9
        col = T.danger if self.state == "error" else T.accent
        with self.canvas:
            for i in range(4):
                k = 0.35 + i * 0.2
                pulse = 1 + 0.04 * math.sin(self.phase * 2 + i)
                Color(*col[:3], 0.25 + 0.15 * (3 - i) / 3)
                rr = r * k * pulse
                Line(circle=(cx, cy, rr), width=dp(1.6))
            Color(*col[:3], 0.9)
            Line(circle=(cx, cy, r * 0.95, self.phase * 57 % 360, self.phase * 57 % 360 + 90), width=dp(2.5))
            Color(*col[:3], 0.55)
            Ellipse(pos=(cx - r * 0.18, cy - r * 0.18), size=(r * 0.36, r * 0.36))

    def stop(self):
        self._ev.cancel()


class Waveform(Widget):
    active = NumericProperty(0)

    def __init__(self, **kw):
        super().__init__(**kw)
        self._h = [0.1] * 28
        self._ev = Clock.schedule_interval(self._tick, 1 / 15)

    def _tick(self, dt):
        self._h = [max(0.06, min(1, h * 0.6 + (random.random() * 0.8 if self.active else 0.05) * 0.4))
                   for h in self._h]
        self.canvas.clear()
        n, w = len(self._h), self.width / len(self._h)
        with self.canvas:
            Color(*T.accent)
            for i, h in enumerate(self._h):
                hh = self.height * h
                Rectangle(pos=(self.x + i * w + w * 0.2, self.center_y - hh / 2), size=(w * 0.6, hh))

    def stop(self):
        self._ev.cancel()


def info_popup(title: str, msg: str) -> Popup:
    box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
    box.add_widget(WrapLabel(msg))
    b = NeonButton("OK")
    box.add_widget(b)
    p = Popup(title=title, content=box, size_hint=(0.9, 0.5), auto_dismiss=True)
    b.bind(on_release=p.dismiss)
    p.open()
    return p


def confirm_popup(title: str, msg: str, on_yes: Callable[[], None], yes_text="Confirm", danger=False) -> Popup:
    box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
    sv = Column()
    sv.add(WrapLabel(msg, size=13))
    box.add_widget(sv)
    row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(10))
    no, yes = NeonButton("Cancel", primary=False), NeonButton(yes_text, danger=danger)
    row.add_widget(no)
    row.add_widget(yes)
    box.add_widget(row)
    p = Popup(title=title, content=box, size_hint=(0.94, 0.7), auto_dismiss=False)
    no.bind(on_release=p.dismiss)
    yes.bind(on_release=lambda *_: (p.dismiss(), on_yes()))
    p.open()
    return p


def text_popup(title: str, text: str, actions: list[tuple[str, Callable[[str], None]]], editable=False) -> Popup:
    """Selectable text view (long-press to select/copy) with action buttons."""
    box = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))
    ti = TextInput(text=text, readonly=not editable, font_size=T.fs(14), background_color=T.surface2,
                   foreground_color=T.text)
    box.add_widget(ti)
    row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6))
    p = Popup(title=title, content=box, size_hint=(0.96, 0.85))
    for label, fn in actions:
        b = NeonButton(label, primary=False)
        b.bind(on_release=lambda *_, fn=fn: fn(ti.selection_text or ti.text))
        row.add_widget(b)
    c = NeonButton("Close")
    c.bind(on_release=p.dismiss)
    row.add_widget(c)
    box.add_widget(row)
    p.open()
    return p


def prompt_popup(title: str, hint: str, on_ok: Callable[[str], None], text="", password=False) -> Popup:
    box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
    ti = field(text=text, hint=hint, password=password)
    box.add_widget(ti)
    row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(10))
    no, ok = NeonButton("Cancel", primary=False), NeonButton("OK")
    row.add_widget(no)
    row.add_widget(ok)
    box.add_widget(row)
    p = Popup(title=title, content=box, size_hint=(0.92, None), height=dp(200))
    no.bind(on_release=p.dismiss)
    ok.bind(on_release=lambda *_: (p.dismiss(), on_ok(ti.text)))
    p.open()
    return p
