"""Declarative settings forms: each control reads/writes SettingsManager, so changes take effect at runtime."""
from __future__ import annotations

from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.slider import Slider
from kivy.uix.spinner import Spinner
from kivy.uix.switch import Switch

from settings.defaults import FIELDS

from .components import Card, WrapLabel, field
from .theme import T


def build_row(settings, key: str) -> BoxLayout:
    f = FIELDS[key]
    card = Card()
    card.add_widget(WrapLabel(f.label, 14, bold=True))
    err = WrapLabel("", 12, color=T.danger)

    def commit(value):
        try:
            settings.set(key, value)
            err.text = ""
            return True
        except ValueError as e:
            err.text = str(e)
            return False

    cur = settings.get(key)
    if f.kind == "bool":
        row = BoxLayout(size_hint_y=None, height=dp(48))
        row.add_widget(WrapLabel("On / Off", 13, color=T.muted))
        sw = Switch(active=cur, size_hint_x=None, width=dp(90))
        sw.bind(active=lambda _, v: commit(v))
        row.add_widget(sw)
        card.add_widget(row)
    elif f.kind == "choice":
        sp = Spinner(text=str(cur), values=list(f.choices), size_hint_y=None, height=dp(48),
                     background_normal="", background_color=T.surface2, color=T.text, font_size=T.fs(14))
        sp.bind(text=lambda _, v: commit(v))
        card.add_widget(sp)
    elif f.kind in ("float", "int"):
        step = 1 if f.kind == "int" and f.hi - f.lo <= 100 else (0.05 if f.kind == "float" else 16)
        lab = WrapLabel(str(cur), 13, color=T.muted)
        sl = Slider(min=f.lo, max=f.hi, value=cur, step=step, size_hint_y=None, height=dp(48))

        def on_val(_, v):
            v = int(v) if f.kind == "int" else round(v, 2)
            lab.text = str(v)
            commit(v)
        sl.bind(value=on_val)
        card.add_widget(lab)
        card.add_widget(sl)
    else:
        multi = f.kind == "text"
        ti = field(multiline=multi, text=str(cur), height=dp(120) if multi else dp(48))
        ti.bind(focus=lambda _, focused: None if focused else commit(ti.text))
        if not multi:
            ti.bind(on_text_validate=lambda *_: commit(ti.text))
        card.add_widget(ti)
    card.add_widget(err)
    return card
