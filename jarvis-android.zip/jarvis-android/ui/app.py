from __future__ import annotations

from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager, SlideTransition

from app_context import AppContext

from .screens.chat import ChatScreen
from .screens.data_screens import DevScreen, DiagnosticsScreen, IntegrationsScreen, MemoryScreen
from .screens.editor import EditorScreen
from .screens.home import HomeScreen
from .screens.settings_screens import PersonalityScreen, ProviderScreen, ThemeScreen, VoiceSettingsScreen
from .screens.voice import VoiceScreen
from .theme import T

SCREENS = {"home": HomeScreen, "chat": ChatScreen, "voice": VoiceScreen, "editor": EditorScreen, "dev": DevScreen,
           "provider": ProviderScreen, "personality": PersonalityScreen, "voice_settings": VoiceSettingsScreen,
           "memory": MemoryScreen, "integrations": IntegrationsScreen, "theme": ThemeScreen,
           "diagnostics": DiagnosticsScreen}


class JarvisApp(App):
    title = "JARVIS"
    chat_prefill = ""

    def build(self):
        self.ctx = AppContext(Path(self.user_data_dir))
        self.sm = ScreenManager(transition=SlideTransition(duration=0.18))
        self.build_screens()
        self.ctx.settings.subscribe(self._on_setting)
        Window.bind(on_keyboard=self._on_key)
        self.go("voice" if self.ctx.settings.get("default_mode") == "voice" else "home")
        return self.sm

    def build_screens(self, current="home"):
        T.apply(self.ctx.settings)
        Window.clearcolor = T.bg
        for s in list(self.sm.screens):
            self.sm.remove_widget(s)
        for name, cls in SCREENS.items():
            self.sm.add_widget(cls(self, name))
        self.sm.current = current

    def _on_setting(self, key, _v):
        if key in ("theme", "font_scale", "high_contrast"):
            cur = self.sm.current
            Clock.schedule_once(lambda dt: self.build_screens(cur), 0.2)

    def go(self, name):
        self.sm.transition.direction = "left" if name != "home" else "right"
        self.sm.current = name

    def _on_key(self, window, key, *a):
        if key == 27 and self.sm.current != "home":  # Android back
            self.go("home")
            return True
        return False

    def on_pause(self):
        return True  # keep state when backgrounded

    def on_stop(self):
        try:
            self.ctx.close()
        except Exception:
            pass
