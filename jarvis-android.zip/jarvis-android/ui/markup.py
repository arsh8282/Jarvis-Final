"""Pure-Python Markdown -> Kivy markup, with light syntax highlighting. No Kivy import (testable)."""
from __future__ import annotations

import re

KW = {"def", "class", "return", "if", "else", "elif", "for", "while", "import", "from", "in", "not", "and", "or",
      "try", "except", "finally", "with", "as", "None", "True", "False", "function", "const", "let", "var", "public",
      "private", "static", "void", "int", "new", "fun", "val", "package", "null"}
_TOKEN = re.compile(r"(?P<c>#[^\n]*|//[^\n]*)|(?P<s>\"[^\"\n]*\"|'[^'\n]*')|(?P<w>[A-Za-z_]\w*)|(?P<o>.)", re.S)


def esc(t: str) -> str:
    return t.replace("&", "&amp;").replace("[", "&bl;").replace("]", "&br;")


def highlight(code: str) -> str:
    out = []
    for m in _TOKEN.finditer(code):
        t = esc(m.group(0))
        if m.group("c"):
            out.append(f"[color=6b7f8e]{t}[/color]")
        elif m.group("s"):
            out.append(f"[color=7ee0a1]{t}[/color]")
        elif m.group("w") and m.group("w") in KW:
            out.append(f"[color=4dd8ff]{t}[/color]")
        else:
            out.append(t)
    return "".join(out)


def code_blocks(text: str) -> list[str]:
    return [m.group(2) for m in re.finditer(r"```(\w*)\n(.*?)```", text, re.S)]


def render(text: str) -> str:
    parts, pos = [], 0
    for m in re.finditer(r"```(\w*)\n?(.*?)```", text, re.S):
        parts.append(_inline(text[pos:m.start()]))
        parts.append("[font=data/fonts/RobotoMono-Regular.ttf]" + highlight(m.group(2).rstrip("\n")) + "[/font]\n")
        pos = m.end()
    parts.append(_inline(text[pos:]))
    return "".join(parts)


def _inline(t: str) -> str:
    t = esc(t)
    t = re.sub(r"^#{1,6}\s*(.+)$", r"[b]\1[/b]", t, flags=re.M)
    t = re.sub(r"\*\*(.+?)\*\*", r"[b]\1[/b]", t)
    t = re.sub(r"`([^`\n]+)`", r"[font=data/fonts/RobotoMono-Regular.ttf][color=9fe8ff]\1[/color][/font]", t)
    return t
