from __future__ import annotations

from kivy.graphics import Color, Rectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen

from ..components import Column, NeonButton
from ..theme import T


class BaseScreen(Screen):
    title = "JARVIS"

    def __init__(self, app, name, title=None, **kw):
        super().__init__(name=name, **kw)
        self.app, self.ctx = app, app.ctx
        self.title = title or self.title
        with self.canvas.before:
            Color(*T.bg)
            self._bg = Rectangle()
        self.bind(pos=lambda *_: setattr(self._bg, "pos", self.pos), size=lambda *_: setattr(self._bg, "size", self.size))
        root = BoxLayout(orientation="vertical")
        bar = BoxLayout(size_hint_y=None, height=dp(56), padding=[dp(8), dp(4)], spacing=dp(8))
        if name != "home":
            back = NeonButton("< Back", primary=False, size_hint_x=None, width=dp(90))
            back.bind(on_release=lambda *_: app.go("home"))
            bar.add_widget(back)
        bar.add_widget(Label(text=self.title.upper(), color=T.accent, bold=True, font_size=T.fs(17), halign="left"))
        root.add_widget(bar)
        self.body = Column()
        root.add_widget(self.body)
        self.add_widget(root)
        self.root_box = root
        self.build()

    def build(self):  # override
        pass
