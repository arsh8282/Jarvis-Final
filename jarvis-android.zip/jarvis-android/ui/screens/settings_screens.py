from __future__ import annotations

from kivy.metrics import dp
from kivy.uix.slider import Slider
from kivy.uix.spinner import Spinner

from providers import create_provider
from providers.base import ProviderError
from security.secrets import mask_key, redact
from settings.defaults import FIELDS

from ..components import Card, NeonButton, WrapLabel, confirm_popup, field, info_popup, run_bg
from ..forms import build_row
from ..theme import T
from .base import BaseScreen


class FormScreen(BaseScreen):
    keys: tuple = ()
    intro = ""

    def build(self):
        if self.intro:
            self.body.add(WrapLabel(self.intro, 13, color=T.muted))
        for k in self.keys:
            self.body.add(build_row(self.ctx.settings, k))
        reset = NeonButton("Reset these to defaults", primary=False)
        reset.bind(on_release=lambda *_: confirm_popup("Reset", "Restore defaults for the settings on this screen?",
                                                       self._reset))
        self.body.add(reset)

    def _reset(self):
        self.ctx.settings.reset(self.keys)
        self.body.clear()
        self.build()


class PersonalityScreen(FormScreen):
    title = "Personality"
    intro = ("Preferences shape how JARVIS answers. They sit BELOW fixed safety rules (honesty about actions, "
             "no fabricated success, no secrets) which cannot be overridden here, and cannot bypass provider or Android restrictions.")
    keys = ("assistant_name", "address_as", "formality", "tone", "response_length", "language", "code_language",
            "hinglish_smali", "coding_style", "task_profile", "custom_instructions", "confirm_actions")


class VoiceSettingsScreen(FormScreen):
    title = "Voice & Language"
    intro = "Speech output/recognition depend on the Android device's speech services."
    keys = ("default_mode", "speak_responses", "spoken_length", "voice_rate", "voice_language", "continuous_listening")


class ThemeScreen(FormScreen):
    title = "Theme & Accessibility"
    keys = ("theme", "font_scale", "high_contrast")


class ProviderScreen(BaseScreen):
    title = "Provider & Model"

    def build(self):
        s, sec = self.ctx.settings, self.ctx.secrets
        for k in ("provider", "model", "temperature", "max_output_tokens"):
            self.body.add(build_row(s, k))
        card = Card()
        card.add_widget(WrapLabel("Gemini API key", 14, bold=True))
        self.keystate = WrapLabel("", 13, color=T.muted)
        self.key = field(password=True, hint="Paste API key (stored in app-private storage)")
        save = NeonButton("Save key")
        clear = NeonButton("Remove key", primary=False, danger=True)
        save.bind(on_release=lambda *_: self.save_key())
        clear.bind(on_release=lambda *_: self.clear_key())
        for w in (self.keystate, self.key, save, clear):
            card.add_widget(w)
        self.body.add(card)
        self.result = self.body.add(WrapLabel("", 13))
        test = NeonButton("Test connection")
        fetch = NeonButton("Fetch available models", primary=False)
        test.bind(on_release=lambda *_: self.test())
        fetch.bind(on_release=lambda *_: self.fetch())
        self.body.add(test)
        self.body.add(fetch)
        self.models = Spinner(text="(fetch models, then pick)", values=[], size_hint_y=None, height=dp(48),
                              background_normal="", background_color=T.surface2, color=T.text)
        self.models.bind(text=self.pick)
        self.body.add(self.models)
        self.body.add(WrapLabel("Token usage is shown only when the API returns it.", 12, color=T.muted))
        self.usage = self.body.add(WrapLabel("", 12))
        self.refresh_key()

    def refresh_key(self):
        k = self.ctx.secrets.get("gemini_api_key")
        self.keystate.text = f"Stored key: {mask_key(k)}" if k else "No key stored."

    def save_key(self):
        v = self.key.text.strip()
        if len(v) < 10 or any(c.isspace() for c in v):
            return self.say("That does not look like a valid key.", True)
        self.ctx.secrets.set("gemini_api_key", v)
        self.key.text = ""
        self.refresh_key()
        self.say("Key saved.")

    def clear_key(self):
        self.ctx.secrets.delete("gemini_api_key")
        self.refresh_key()
        self.say("Key removed.")

    def say(self, t, err=False):
        self.result.text, self.result.color = redact(t), (T.danger if err else T.ok)

    def _provider(self):
        return create_provider(self.ctx.settings.get("provider"), self.ctx.secrets.get("gemini_api_key"),
                               self.ctx.settings.get("model"))

    def test(self):
        self.say("Testing...")
        p = self._provider()

        def done(res, err):
            if err is not None:
                return self.say(err.message if isinstance(err, ProviderError) else str(err), True)
            self.say(f"Connected. Reply: {res}")
            u = getattr(p, "last_usage", None)
            self.usage.text = f"Usage reported by API: {u}" if u else ""
        run_bg(p.test_connection, done)

    def fetch(self):
        self.say("Fetching models...")
        p = self._provider()

        def done(res, err):
            if err is not None:
                return self.say((err.message if isinstance(err, ProviderError) else str(err)) +
                                " Enter the model id manually above.", True)
            self.models.values = res
            self.say(f"{len(res)} models available.")
        run_bg(p.list_models, done)

    def pick(self, _, text):
        if text in self.models.values:
            self.ctx.settings.set("model", text)
            self.say(f"Model set to {text}. Reopen this screen to see it in the field.")
