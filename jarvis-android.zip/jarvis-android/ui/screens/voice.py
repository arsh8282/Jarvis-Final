from __future__ import annotations

import threading

from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout

from providers.base import ProviderError
from security import permissions
from voice.speech_output import to_spoken

from ..components import CoreWidget, NeonButton, WrapLabel, run_bg, Waveform
from ..theme import T
from .base import BaseScreen


class VoiceScreen(BaseScreen):
    title = "Voice"

    def build(self):
        self.last_reply, self.continuous = "", False
        self.core = CoreWidget(size_hint_y=None, height=dp(220))
        self.wave = Waveform(size_hint_y=None, height=dp(60))
        self.state = WrapLabel("Idle", 18, color=T.accent, bold=True)
        self.info = WrapLabel("", 13, color=T.muted)
        self.transcript = WrapLabel("", 14)
        for w in (self.core, self.wave, self.state, self.info, self.transcript):
            self.body.add(w)
        self.ptt = NeonButton("Hold to talk", height=dp(72))
        self.ptt.bind(on_press=lambda *_: self.start_listen(), on_release=lambda *_: self.stop_listen())
        self.body.add(self.ptt)
        row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6))
        for label, fn in [("Stop speaking", self.interrupt), ("Repeat", self.repeat), ("Text mode", lambda: self.app.go("chat"))]:
            b = NeonButton(label, primary=False)
            b.bind(on_release=lambda *_, fn=fn: fn())
            row.add_widget(b)
        self.body.add(row)
        self.cont_btn = NeonButton("Continuous listening: OFF", primary=False)
        self.cont_btn.bind(on_release=lambda *_: self.toggle_continuous())
        self.body.add(self.cont_btn)

    def set_state(self, s, info=""):
        self.core.state = {"Idle": "idle", "Listening": "listening", "Processing": "processing",
                           "Speaking": "speaking", "Interrupted": "idle", "Error": "error"}[s]
        self.wave.active = 1 if s in ("Listening", "Speaking") else 0
        self.state.text = s + ("  [REC]" if s == "Listening" else "")
        self.info.text = info

    def on_pre_enter(self, *a):
        si, so = self.ctx.speech_in, self.ctx.speech_out
        notes = []
        if not si.available:
            notes.append("Speech input unavailable: " + si.reason + " You can still type in Text mode.")
        if not so.available:
            notes.append("Speech output unavailable: " + so.reason)
        if permissions.check("RECORD_AUDIO") == "denied":
            notes.append("Microphone permission denied. Open Integrations to grant it.")
        self.set_state("Idle", "\n".join(notes))

    def on_leave(self, *a):
        self.continuous = False
        self.ctx.speech_in.stop()
        self.ctx.speech_out.stop()

    def start_listen(self):
        self.ctx.speech_out.stop()
        err = self.ctx.speech_in.start(self.ctx.settings.get("voice_language"))
        if err:
            self.set_state("Error", err)
        else:
            self.set_state("Listening", "Release to send.")

    def stop_listen(self):
        if self.state.text.startswith("Error"):
            return
        self.ctx.speech_in.stop()
        self.set_state("Processing", "Recognising...")
        Clock.schedule_once(lambda dt: self._collect(0), 1.0)

    def _collect(self, tries):
        text, err = self.ctx.speech_in.poll()
        if text:
            self.transcript.text = f"[b]You:[/b] {text}"
            return self._ask(text)
        if tries < 4:
            return Clock.schedule_once(lambda dt: self._collect(tries + 1), 0.7)
        self.set_state("Error", err or "Nothing recognised. Check the network and try again.")

    def _ask(self, text):
        self.set_state("Processing", "Asking the assistant...")

        def done(reply, err):
            if err is not None:
                msg = err.message if isinstance(err, ProviderError) else str(err)
                return self.set_state("Error", msg)
            self.last_reply = reply
            self.transcript.text += f"\n[b]JARVIS:[/b] {reply}"
            self._speak(reply)
        run_bg(lambda: self.ctx.orch.send(text), done)

    def _speak(self, reply):
        s = self.ctx.settings
        if s.get("speak_responses"):
            spoken = to_spoken(reply, s.get("spoken_length"))
            if self.ctx.speech_out.speak(spoken, s.get("voice_rate"), s.get("voice_language")):
                self.set_state("Speaking", "")
                return Clock.schedule_once(self._watch_speech, 0.5)
            self.set_state("Idle", "Reply shown as text (speech output unavailable).")
        else:
            self.set_state("Idle", "Spoken responses are off in Voice Settings.")
        self._maybe_continue()

    def _watch_speech(self, dt):
        if self.state.text.startswith("Speaking"):
            if self.ctx.speech_out.is_speaking():
                Clock.schedule_once(self._watch_speech, 0.5)
            else:
                self.set_state("Idle")
                self._maybe_continue()

    def interrupt(self):
        self.ctx.speech_out.stop()
        self.set_state("Interrupted", "Speech stopped.")

    def repeat(self):
        if self.last_reply:
            self._speak(self.last_reply)

    def toggle_continuous(self):
        if not self.ctx.settings.get("continuous_listening"):
            return self.set_state("Idle", "Enable 'Allow continuous listening' in Voice Settings first (opt-in).")
        self.continuous = not self.continuous
        self.cont_btn.text = f"Continuous listening: {'ON - tap to stop' if self.continuous else 'OFF'}"
        if self.continuous:
            self._maybe_continue()
        else:
            self.ctx.speech_in.stop()
            self.set_state("Idle")

    def _maybe_continue(self):
        if self.continuous:
            Clock.schedule_once(lambda dt: (self.start_listen(), Clock.schedule_once(lambda d: self.stop_listen(), 6)), 0.5)
