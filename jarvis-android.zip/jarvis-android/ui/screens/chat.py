from __future__ import annotations

import threading

from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout

from providers.base import Cancelled, ProviderError

from .. import markup
from ..components import (NeonButton, WrapLabel, confirm_popup, field, info_popup, prompt_popup, run_bg, text_popup)
from ..theme import T
from .base import BaseScreen


class Bubble(ButtonBehavior, BoxLayout):
    def __init__(self, role, text, on_tap, **kw):
        super().__init__(orientation="vertical", size_hint_y=None, padding=dp(10), **kw)
        self.role, self.raw = role, text
        who = "You" if role == "user" else "JARVIS"
        self.head = WrapLabel(f"[b]{who}[/b]", 12, color=T.accent if role != "user" else T.muted)
        self.lbl = WrapLabel(markup.render(text), 15)
        self.add_widget(self.head)
        self.add_widget(self.lbl)
        self.lbl.bind(height=lambda *_: setattr(self, "height", self.head.height + self.lbl.height + dp(24)))
        self.bind(on_release=lambda *_: on_tap(self))

    def set_text(self, text):
        self.raw = text
        self.lbl.text = markup.render(text)


class ChatScreen(BaseScreen):
    title = "Chat"

    def build(self):
        self.busy, self.cancel, self.last_error = False, None, None
        self.status = WrapLabel("", 12, color=T.muted)
        self.root_box.add_widget(self.status, index=1)
        tools = GridLayout(cols=4, size_hint_y=None, height=dp(48), spacing=dp(4), padding=[dp(6), 0])
        for label, fn in [("New", self.new_chat), ("Retry", self.retry), ("Regen", self.regen), ("Export", self.export)]:
            b = NeonButton(label, primary=False)
            b.bind(on_release=lambda *_, fn=fn: fn())
            tools.add_widget(b)
        self.root_box.add_widget(tools)
        row = BoxLayout(size_hint_y=None, height=dp(56), spacing=dp(6), padding=dp(6))
        self.input = field(hint="Message JARVIS...", multiline=True, height=dp(48))
        self.send_btn = NeonButton("Send", size_hint_x=None, width=dp(80))
        self.send_btn.bind(on_release=lambda *_: self.stop() if self.busy else self.send())
        row.add_widget(self.input)
        row.add_widget(self.send_btn)
        self.root_box.add_widget(row)

    # ----- rendering -----
    def on_pre_enter(self, *a):
        prefill = getattr(self.app, "chat_prefill", "")
        if prefill:
            self.input.text, self.app.chat_prefill = prefill, ""
        self.refresh()

    def refresh(self):
        self.body.clear()
        msgs = self.ctx.orch.conversation.messages
        if not msgs:
            self.body.add(WrapLabel("No messages yet. Ask anything - or type /remember <fact> to save a memory "
                                    "(when memory is enabled).", 14, color=T.muted))
        for m in msgs:
            self.body.add(Bubble(m.role, m.content, self.tap))
        self.send_btn.text = "Stop" if self.busy else "Send"
        self.body.to_bottom()

    def set_status(self, t, err=False):
        self.status.text = t
        self.status.color = T.danger if err else T.muted

    # ----- actions -----
    def send(self):
        text = self.input.text.strip()
        if not text or self.busy:
            return
        self.input.text = ""
        self._run(lambda cb, ev: self.ctx.orch.send(text, cb, ev), user_text=text)

    def retry(self):
        if not self.busy:
            self._run(lambda cb, ev: self.ctx.orch.retry(cb, ev))

    def regen(self):
        if not self.busy:
            self._run(lambda cb, ev: self.ctx.orch.regenerate(cb, ev))

    def stop(self):
        if self.cancel:
            self.cancel.set()

    def _run(self, fn, user_text=None):
        self.busy, self.cancel = True, threading.Event()
        self.set_status("Thinking... (tap Stop to cancel)")
        msgs = self.ctx.orch.conversation.messages
        if user_text:
            self.body.add(Bubble("user", user_text, self.tap))
        bubble = Bubble("assistant", "...", self.tap)
        self.body.add(bubble)
        self.body.to_bottom()
        self.send_btn.text = "Stop"
        buf: list[str] = []

        def on_chunk(c):
            buf.append(c)
            Clock.schedule_once(lambda dt: (bubble.set_text("".join(buf)), self.body.to_bottom()))

        def work():
            return fn(on_chunk, self.cancel)

        def done(res, err):
            self.busy = False
            if isinstance(err, Cancelled):
                self.set_status("Stopped.")
            elif isinstance(err, ProviderError):
                self.set_status(f"Error: {err.message}  (Retry is available)", True)
            elif err is not None:
                self.set_status(f"Error: {err}", True)
            else:
                self.set_status("")
            self.refresh()
        run_bg(work, done)

    def new_chat(self):
        if self.busy:
            return
        self.ctx.orch.new_conversation()
        self.set_status("")
        self.refresh()

    def export(self):
        conv = self.ctx.orch.conversation
        if not conv.messages:
            return info_popup("Export", "Nothing to export.")
        md = "\n\n".join(f"**{m.role.capitalize()}:** {m.content}" for m in conv.messages)
        text_popup("Export conversation", md, [("Copy", self._copy), ("Share", self._share),
                                               ("Save", self._save_text("conversation.md"))])

    def tap(self, bubble):
        acts = [("Copy", self._copy), ("Share", self._share)]
        blocks = markup.code_blocks(bubble.raw)
        if blocks:
            acts.append(("Copy code", lambda _t: self._copy(blocks[0])))
            acts.append(("Save code", lambda _t: self._save_text("snippet.txt")(blocks[0])))
        if bubble.role == "user":
            acts.append(("Edit", lambda _t: self._edit(bubble)))
        text_popup("Message (long-press to select)", bubble.raw, acts)

    def _edit(self, bubble):
        msgs = self.ctx.orch.conversation.messages
        if self.busy or not msgs or msgs[-1].role not in ("user", "assistant"):
            return
        # Edit resends the last user message: drop the last exchange and put the text back in the input.
        conv = self.ctx.orch.conversation
        if conv.messages[-1].role == "assistant":
            conv.pop_last("assistant")
        if conv.messages and conv.messages[-1].role == "user" and conv.messages[-1].content == bubble.raw:
            conv.pop_last("user")
            self.input.text = bubble.raw
            self.refresh()
        else:
            info_popup("Edit", "Only the most recent message can be edited.")

    def _copy(self, text):
        try:
            self.ctx.platform.copy_text(text)
            self.set_status("Copied.")
        except Exception as e:
            self.set_status(str(e), True)

    def _share(self, text):
        r = self.ctx.tools.execute("share_text", {"text": text}, confirm=lambda d: True)
        self.set_status(r.message, not r.ok)

    def _save_text(self, default_name):
        def save(text):
            def go(name):
                r = self.ctx.tools.execute("write_file", {"path": name.strip(), "content": text},
                                           confirm=lambda d: True)
                info_popup("Save", r.message)
            prompt_popup("Save to workspace as", "file name", go, text=default_name)
        return save
