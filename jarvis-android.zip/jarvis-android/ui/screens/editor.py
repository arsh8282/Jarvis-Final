from __future__ import annotations

from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.checkbox import CheckBox
from kivy.uix.gridlayout import GridLayout
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput

from editor import diff
from editor.text_actions import AI_ACTIONS, REPLACING, ChangeReview, TextDocument, build_prompt, strip_fences
from providers.base import GenerationConfig, ProviderError, ChatMessage
from security.validation import ValidationError, validate_json, validate_xml

from ..components import Card, NeonButton, WrapLabel, confirm_popup, field, info_popup, prompt_popup, run_bg
from ..theme import T
from .base import BaseScreen


class EditorScreen(BaseScreen):
    title = "Editor"

    def build(self):
        self.doc, self.review, self.path, self.checks = TextDocument(""), None, "", []
        self.status = self.body.add(WrapLabel("", 12, color=T.muted))
        self.editor = TextInput(text="", size_hint_y=None, height=dp(300), font_size=T.fs(14),
                                font_name="data/fonts/RobotoMono-Regular.ttf", background_color=T.surface2,
                                foreground_color=T.text, cursor_color=T.accent)
        self.editor.bind(text=lambda _, v: self._sync(v))
        self.body.add(self.editor)
        self.body.add(self._row([("All", self.select_all), ("Copy", self.copy), ("Cut", self.cut), ("Paste", self.paste)]))
        self.body.add(self._row([("Undo", self.undo), ("Redo", self.redo), ("Open", self.open_file), ("Save", self.save)]))
        self.find = field(hint="Find"); self.repl = field(hint="Replace with")
        self.body.add(self.find); self.body.add(self.repl)
        self.body.add(self._row([("Find", self.do_find), ("Replace all", self.do_replace), ("Validate", self.validate),
                                 ("Share", self.share)]))
        card = Card()
        card.add_widget(WrapLabel("AI assistance (acts on the selection, or the whole text)", 13, bold=True))
        self.action = Spinner(text="Rewrite", values=list(AI_ACTIONS), size_hint_y=None, height=dp(48),
                              background_normal="", background_color=T.surface2, color=T.text)
        self.arg = field(hint="Target language (for Translate)")
        run = NeonButton("Run AI action")
        run.bind(on_release=lambda *_: self.run_ai())
        for w in (self.action, self.arg, run):
            card.add_widget(w)
        self.body.add(card)
        self.preview_box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(6))
        self.preview_box.bind(minimum_height=self.preview_box.setter("height"))
        self.body.add(self.preview_box)

    def _row(self, items):
        g = GridLayout(cols=len(items), size_hint_y=None, height=dp(48), spacing=dp(4))
        for label, fn in items:
            b = NeonButton(label, primary=False)
            b.bind(on_release=lambda *_, fn=fn: fn())
            g.add_widget(b)
        return g

    def say(self, t, err=False):
        self.status.text, self.status.color = t, (T.danger if err else T.muted)

    def _sync(self, v):
        self.doc.set_text(v)

    # basic editing
    def select_all(self): self.editor.select_all()
    def copy(self): self.editor.copy()
    def cut(self): self.editor.cut()
    def paste(self): self.editor.paste()

    def undo(self):
        if self.doc.undo():
            self._silent(self.doc.text)

    def redo(self):
        if self.doc.redo():
            self._silent(self.doc.text)

    def _silent(self, text):
        self.editor.unbind(text=self._sync)
        self.editor.text = text
        self.editor.bind(text=self._sync)

    def do_find(self):
        hits = self.doc.find_all(self.find.text)
        if not hits:
            return self.say("No matches.")
        h = hits[0]
        self.editor.select_text(h, h + len(self.find.text))
        self.say(f"{len(hits)} match(es); first selected.")

    def do_replace(self):
        n = self.doc.replace_all(self.find.text, self.repl.text)
        self._silent(self.doc.text)
        self.say(f"Replaced {n} occurrence(s). Undo is available.")

    def validate(self):
        t = self.editor.text.strip()
        try:
            msg = validate_json(t) if t.startswith(("{", "[")) else validate_xml(t)
            self.say(msg)
        except ValidationError as e:
            self.say(str(e), True)

    def share(self):
        r = self.ctx.tools.execute("share_text", {"text": self.editor.text}, confirm=lambda d: True)
        self.say(r.message, not r.ok)

    # files (workspace only)
    def open_file(self):
        def go(name):
            r = self.ctx.tools.execute("read_file", {"path": name.strip()})
            if r.ok:
                self.path = name.strip()
                self._silent(r.data); self.doc = TextDocument(r.data)
                self.say(f"Opened {self.path}")
            else:
                self.say(r.message, True)
        prompt_popup("Open from workspace", "relative path e.g. notes/a.txt", go, text=self.path)

    def save(self):
        def go(name):
            self.path = name.strip()
            r = self.ctx.tools.execute("write_file", {"path": self.path, "content": self.editor.text},
                                       confirm=lambda d: self._confirm_sync(d))
            self.say(r.message, not r.ok)
        prompt_popup("Save to workspace as", "relative path", go, text=self.path or "note.txt")

    @staticmethod
    def _confirm_sync(_desc):
        return True  # the user just pressed OK on the save dialog naming the file; backups are kept

    # AI with preview
    def run_ai(self):
        a = self.action.text
        s, e = sorted((self.editor.selection_from, self.editor.selection_to))
        has_sel = self.editor.selection_text != ""
        target = self.editor.selection_text if has_sel else self.editor.text
        if not target.strip():
            return self.say("Nothing to process.", True)
        self.say("Asking AI...")
        prompt = build_prompt(a, target, self.arg.text)
        orch = self.ctx.orch
        st = self.ctx.settings

        def work():
            from assistant.prompts import build_system_prompt
            system = build_system_prompt(st.snapshot(), orch.memory.active_texts())
            cfg = GenerationConfig(st.get("temperature"), st.get("max_output_tokens"))
            return orch.provider().generate([ChatMessage("user", prompt)], system, cfg)

        def done(reply, err):
            if err is not None:
                return self.say(err.message if isinstance(err, ProviderError) else str(err), True)
            if a in REPLACING:
                new_t = strip_fences(reply)
                self.show_review(ChangeReview(target, new_t, s if has_sel else None, e if has_sel else None))
            else:
                self.say("")
                info_popup(a, reply)
        run_bg(work, done)

    def show_review(self, rv: ChangeReview):
        self.review = rv
        self.preview_box.clear_widgets()
        self.checks = []
        n = rv.hunk_count()
        if n == 0:
            self.say("AI proposed no changes.")
            return
        self.preview_box.add_widget(WrapLabel(f"[b]Proposed changes ({n})[/b] - tick hunks to apply. Original is untouched until Apply.", 13))
        for i in range(n):
            row = BoxLayout(size_hint_y=None, height=dp(90), spacing=dp(6))
            cb = CheckBox(active=True, size_hint_x=None, width=dp(44))
            self.checks.append(cb)
            lab = WrapLabel(diff.describe_hunk(rv.original, rv.proposed, i), 12)
            lab.size_hint_y = 1
            row.add_widget(cb); row.add_widget(lab)
            self.preview_box.add_widget(row)
        self.preview_box.add_widget(self._row([("Apply", self.apply), ("Cancel", self.cancel_review), ("Restore", self.restore),
                                               ("Copy result", self.copy_result)]))

    def apply(self):
        rv = self.review
        if not rv:
            return
        self._backup_text = self.editor.text
        sel = [i for i, c in enumerate(self.checks) if c.active]
        result = rv.result(sel)
        if rv.start is not None:
            full = self.editor.text[:rv.start] + result + self.editor.text[rv.end:]
        else:
            full = result
        self.doc.set_text(full)
        self._silent(full)
        self.say(f"Applied {len(sel)} hunk(s). Use Restore or Undo to go back.")
        self.preview_box.clear_widgets()
        self.review = None

    def cancel_review(self):
        self.review = None
        self.preview_box.clear_widgets()
        self.say("Cancelled. Nothing was changed.")

    def restore(self):
        if getattr(self, "_backup_text", None) is None:
            return self.say("Nothing to restore yet.")
        self.doc.set_text(self._backup_text)
        self._silent(self._backup_text)
        self.say("Restored the text from before the last Apply.")

    def copy_result(self):
        if self.review:
            self.ctx.platform.copy_text(self.review.result([i for i, c in enumerate(self.checks) if c.active]))
            self.say("Copied.")
