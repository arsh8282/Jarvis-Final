from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout

from ..components import CoreWidget, NeonButton, WrapLabel
from ..theme import T
from .base import BaseScreen

TILES = [("Text Chat", "chat"), ("Voice", "voice"), ("Editor", "editor"), ("Dev Workspace", "dev"),
         ("Provider & Model", "provider"), ("Personality", "personality"), ("Voice Settings", "voice_settings"),
         ("Memory & History", "memory"), ("Android Integrations", "integrations"),
         ("Theme & Accessibility", "theme"), ("Diagnostics & Privacy", "diagnostics")]


class HomeScreen(BaseScreen):
    title = "JARVIS"

    def build(self):
        self.core = CoreWidget(size_hint_y=None, height=dp(200))
        self.body.add(self.core)
        self.status = self.body.add(WrapLabel("", 13, color=T.muted))
        grid = GridLayout(cols=2, spacing=dp(10), size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))
        for label, target in TILES:
            b = NeonButton(label, height=dp(64))
            b.bind(on_release=lambda *_, t=target: self.app.go(t))
            grid.add_widget(b)
        self.body.add(grid)

    def on_pre_enter(self, *a):
        s = self.ctx.settings
        key = self.ctx.secrets.has("gemini_api_key")
        prov = s.get("provider")
        note = "demo mode (offline mock)" if prov == "mock" else f"{prov} / {s.get('model')} - key {'set' if key else 'MISSING'}"
        self.status.text = (f"Provider: {note}\nDefault mode: {s.get('default_mode')}  |  "
                            f"Memory: {'on' if s.get('memory_enabled') else 'off'}  |  "
                            f"History: {'on' if s.get('history_enabled') else 'off'}")
