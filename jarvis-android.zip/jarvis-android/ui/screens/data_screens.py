from __future__ import annotations

from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout

from ..components import (Card, NeonButton, WrapLabel, confirm_popup, field, info_popup, prompt_popup, text_popup)
from ..forms import build_row
from ..theme import T
from .base import BaseScreen


class MemoryScreen(BaseScreen):
    title = "Memory & History"

    def build(self):
        s = self.ctx.settings
        self.body.add(WrapLabel(
            "[b]Stored locally:[/b] history, memories, settings. [b]Sent to your AI provider:[/b] the current "
            "conversation (trimmed), your instructions, and memories only while memory is enabled. "
            "Turning memory off stops saving new memories (existing ones are kept but not sent) - chat history is a "
            "separate switch.", 12, color=T.muted))
        self.body.add(build_row(s, "history_enabled"))
        self.body.add(build_row(s, "memory_enabled"))
        self.search = field(hint="Search history")
        self.search.bind(text=lambda *_: self.reload())
        self.body.add(self.search)
        self.list_box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(8))
        self.list_box.bind(minimum_height=self.list_box.setter("height"))
        self.body.add(self.list_box)

    def on_pre_enter(self, *a):
        self.reload()

    def reload(self):
        lb = self.list_box
        lb.clear_widgets()
        lb.add_widget(WrapLabel("[b]Conversations[/b]", 14, color=T.accent))
        for c in self.ctx.history.list(self.search.text)[:50]:
            card = Card()
            card.add_widget(WrapLabel(c["title"], 14))
            row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
            for label, fn in [("Open", self.open), ("Rename", self.rename), ("Export", self.export), ("Delete", self.delete)]:
                b = NeonButton(label, primary=False, danger=label == "Delete", height=dp(44))
                b.bind(on_release=lambda *_, fn=fn, cid=c["id"]: fn(cid))
                row.add_widget(b)
            card.add_widget(row)
            lb.add_widget(card)
        clr = NeonButton("Clear ALL history", danger=True)
        clr.bind(on_release=lambda *_: confirm_popup("Clear history", "Delete every saved conversation? This cannot be undone.",
                                                     lambda: (self.ctx.history.clear_all(), self.ctx.orch.new_conversation(), self.reload()),
                                                     danger=True))
        lb.add_widget(clr)
        exp = NeonButton("Export all history (JSON)", primary=False)
        exp.bind(on_release=lambda *_: text_popup("History JSON", self.ctx.history.export_json(),
                                                  [("Copy", self.ctx.platform.copy_text), ("Share", lambda t: self.ctx.tools.execute("share_text", {"text": t}, confirm=lambda d: True))]))
        lb.add_widget(exp)
        lb.add_widget(WrapLabel("[b]Memories[/b]", 14, color=T.accent))
        if not self.ctx.settings.get("memory_enabled"):
            lb.add_widget(WrapLabel("Memory is OFF: no new memories will be saved.", 12, color=T.muted))
        add = NeonButton("Add memory")
        add.bind(on_release=lambda *_: prompt_popup("New memory", "e.g. I prefer metric units", self.add_mem))
        lb.add_widget(add)
        for m in self.ctx.memory.list():
            card = Card()
            card.add_widget(WrapLabel(m["content"], 13))
            row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
            e, d = NeonButton("Edit", primary=False, height=dp(44)), NeonButton("Delete", primary=False, danger=True, height=dp(44))
            e.bind(on_release=lambda *_, m=m: prompt_popup("Edit memory", "", lambda t, i=m["id"]: self._try(lambda: self.ctx.memory.update(i, t)), text=m["content"]))
            d.bind(on_release=lambda *_, i=m["id"]: (self.ctx.memory.delete(i), self.reload()))
            row.add_widget(e); row.add_widget(d)
            card.add_widget(row)
            lb.add_widget(card)
        if self.ctx.memory.list():
            c = NeonButton("Clear all memories", danger=True)
            c.bind(on_release=lambda *_: confirm_popup("Clear memories", "Delete all saved memories?",
                                                       lambda: (self.ctx.memory.clear(), self.reload()), danger=True))
            lb.add_widget(c)

    def _try(self, fn):
        try:
            fn()
        except Exception as e:
            info_popup("Error", str(e))
        self.reload()

    def add_mem(self, text):
        self._try(lambda: self.ctx.memory.add(text))

    def open(self, cid):
        self.ctx.orch.open_conversation(cid)
        self.app.go("chat")

    def rename(self, cid):
        prompt_popup("Rename", "title", lambda t: self._try(lambda: self.ctx.history.rename(cid, t)),
                     text=self.ctx.history.title(cid) or "")

    def export(self, cid):
        text_popup("Export", self.ctx.history.export_markdown(cid), [("Copy", self.ctx.platform.copy_text)])

    def delete(self, cid):
        confirm_popup("Delete", "Delete this conversation?", lambda: (self.ctx.history.delete(cid), self.reload()), danger=True)


class IntegrationsScreen(BaseScreen):
    title = "Android Integrations"

    def build(self):
        from security import permissions
        self.perm_box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(6))
        self.perm_box.bind(minimum_height=self.perm_box.setter("height"))
        self.body.add(self.perm_box)
        self.out = WrapLabel("", 13)
        self.body.add(self.out)
        self.body.add(WrapLabel("[b]Actions[/b] - each shows exactly what Android reported.", 14, color=T.accent))
        for label, fn in [("Request microphone permission", self.req_mic), ("Open JARVIS app settings", lambda: self.run("open_settings", {"screen": "app"})),
                          ("Open Wi-Fi settings", lambda: self.run("open_settings", {"screen": "wifi"})),
                          ("Open Accessibility settings", self.acc), ("Open a URL", self.url), ("Launch an app by package", self.app_launch),
                          ("WhatsApp draft", self.wa)]:
            b = NeonButton(label, primary=False)
            b.bind(on_release=lambda *_, fn=fn: fn())
            self.body.add(b)
        self.body.add(WrapLabel(
            "Limits: JARVIS cannot control other apps, read their data, or edit text inside them. For text in another app, "
            "use Share > JARVIS (when available) or paste from the clipboard into the Editor, then copy/share the result back. "
            "Opening WhatsApp with a draft is not sending. An AccessibilityService is NOT included in this build.", 12, color=T.muted))

    def on_pre_enter(self, *a):
        from security import permissions
        self.perm_box.clear_widgets()
        self.perm_box.add_widget(WrapLabel("[b]Permission & integration status[/b]", 14, color=T.accent))
        for r in permissions.status_report():
            self.perm_box.add_widget(WrapLabel(f"{r['name']}: [b]{r['status']}[/b] - {r['purpose']}", 12))
        self.perm_box.add_widget(WrapLabel(f"Running on Android: [b]{self.ctx.platform.available}[/b]", 12))
        self.perm_box.add_widget(WrapLabel(f"Speech input: [b]{'available' if self.ctx.speech_in.available else 'unavailable'}[/b]   "
                                           f"Speech output: [b]{'available' if self.ctx.speech_out.available else 'unavailable'}[/b]", 12))

    def run(self, name, args):
        r = self.ctx.tools.execute(name, args, confirm=lambda d: True)
        self.out.text = r.message
        self.out.color = T.ok if r.ok else T.danger

    def req_mic(self):
        from security import permissions
        self.out.text = "Permission dialog requested." if permissions.request(["RECORD_AUDIO"]) else "Only available on Android."

    def acc(self):
        confirm_popup("Accessibility", "This opens Android's Accessibility settings. JARVIS does not ship an "
                      "AccessibilityService in this build, so nothing is enabled by it.", lambda: self.run("open_settings", {"screen": "accessibility"}), "Open")

    def url(self):
        prompt_popup("Open URL", "https://...", lambda u: self._confirm("open_url", {"url": u.strip()}))

    def app_launch(self):
        prompt_popup("Package name", "e.g. com.whatsapp", lambda p: self._confirm("open_app", {"package": p.strip()}))

    def wa(self):
        def with_phone(phone):
            prompt_popup("Message text", "Draft", lambda t: self._confirm("whatsapp_draft", {"phone": phone.strip(), "text": t}))
        prompt_popup("Recipient (with country code)", "+919876543210", with_phone)

    def _confirm(self, name, args):
        desc = self.ctx.tools.describe(name, args) if name in self.ctx.tools.names() else name
        confirm_popup("Confirm action", desc, lambda: self.run(name, args), "Proceed")


class DevScreen(BaseScreen):
    title = "Developer Workspace"

    def build(self):
        self.cwd = ""
        self.info = self.body.add(WrapLabel("", 12, color=T.muted))
        self.wsdir = field(hint="Workspace directory (blank = app default)", text=self.ctx.settings.get("workspace_dir"))
        self.body.add(self.wsdir)
        b = NeonButton("Set workspace directory")
        b.bind(on_release=lambda *_: self.set_ws())
        self.body.add(b)
        self.q = field(hint="Search text in workspace")
        self.body.add(self.q)
        row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(4))
        for label, fn in [("Search", self.search), ("New file", self.new_file), ("Up", self.up)]:
            x = NeonButton(label, primary=False)
            x.bind(on_release=lambda *_, fn=fn: fn())
            row.add_widget(x)
        self.body.add(row)
        self.listing = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(6))
        self.listing.bind(minimum_height=self.listing.setter("height"))
        self.body.add(self.listing)

    def on_pre_enter(self, *a):
        self.show()

    def show(self):
        self.info.text = f"Workspace: {self.ctx.workspace.root}  |  folder: /{self.cwd}\nFile operations are restricted to this folder; deletes and overwrites keep recoverable backups."
        self.listing.clear_widgets()
        try:
            entries = self.ctx.workspace.list_dir(self.cwd)
        except Exception as e:
            return self.listing.add_widget(WrapLabel(str(e), 13, color=T.danger))
        if not entries:
            self.listing.add_widget(WrapLabel("Empty folder. Create a file or ask JARVIS to draft one.", 13, color=T.muted))
        for e in entries:
            b = NeonButton(("[DIR] " if e["dir"] else "") + e["name"], primary=False, height=dp(44))
            b.bind(on_release=lambda *_, e=e: self.click(e))
            self.listing.add_widget(b)

    def click(self, e):
        if e["dir"]:
            self.cwd = e["path"]
            return self.show()
        from ..components import text_popup
        acts = [("Edit", lambda _t, p=e["path"]: self.edit(p)), ("Rename", lambda _t, p=e["path"]: self.rename(p)),
                ("Delete", lambda _t, p=e["path"]: self.delete(p)), ("Backups", lambda _t, p=e["path"]: self.backups(p)),
                ("Ask AI", lambda _t, p=e["path"]: self.ask(p))]
        r = self.ctx.tools.execute("read_file", {"path": e["path"]})
        text_popup(e["path"], r.data if r.ok else r.message, acts)

    def edit(self, p):
        r = self.ctx.tools.execute("read_file", {"path": p})
        if r.ok:
            ed = self.app.sm.get_screen("editor")
            ed.path = p
            ed._silent(r.data)
            from editor.text_actions import TextDocument
            ed.doc = TextDocument(r.data)
            self.app.go("editor")

    def ask(self, p):
        r = self.ctx.tools.execute("read_file", {"path": p})
        if r.ok:
            self.app.chat_prefill = f"Explain this file and point out likely bugs (I have not run it):\n\n```\n{r.data[:6000]}\n```"
            self.app.go("chat")

    def rename(self, p):
        prompt_popup("Rename / move to", "new relative path", lambda n: self._exec("rename_file", {"src": p, "dst": n.strip()}), text=p)

    def delete(self, p):
        self._exec("delete_file", {"path": p})

    def _exec(self, name, args):
        desc = self.ctx.tools.describe(name, args)
        confirm_popup("Confirm", desc, lambda: (info_popup("Result", self.ctx.tools.execute(name, args, confirm=lambda d: True).message), self.show()),
                      danger=name == "delete_file")

    def backups(self, p):
        bs = self.ctx.workspace.list_backups(p)
        if not bs:
            return info_popup("Backups", "No backups for this file yet.")
        newest = bs[-1]
        confirm_popup("Restore backup", f"{len(bs)} backup(s). Restore the newest ({newest})? The current version is backed up first.",
                      lambda: info_popup("Restore", self._restore(p, newest)), "Restore")

    def _restore(self, p, n):
        try:
            return f"Restored {self.ctx.workspace.restore(p, n)}"
        except Exception as e:
            return str(e)

    def new_file(self):
        prompt_popup("New file", "relative path", lambda n: self._exec("write_file", {"path": n.strip(), "content": ""}))

    def up(self):
        self.cwd = self.cwd.rsplit("/", 1)[0] if "/" in self.cwd else ""
        self.show()

    def search(self):
        from ..components import text_popup
        hits = self.ctx.workspace.search(self.q.text)
        text_popup("Search results", "\n".join(f"{h['path']}:{h['line']}: {h['text']}" for h in hits) or "No matches.", [])

    def set_ws(self):
        try:
            self.ctx.settings.set("workspace_dir", self.wsdir.text)
            self.cwd = ""
            self.show()
        except ValueError as e:
            info_popup("Invalid", str(e))


class DiagnosticsScreen(BaseScreen):
    title = "Diagnostics & Privacy"

    def build(self):
        self.info = self.body.add(WrapLabel("", 13))
        self.body.add(build_row(self.ctx.settings, "diagnostic_logging"))
        self.logv = self.body.add(WrapLabel("", 11, color=T.muted))
        clear = NeonButton("Clear log file", primary=False)
        clear.bind(on_release=lambda *_: (self.ctx.log_path.write_text("") if self.ctx.log_path.exists() else None, self.on_pre_enter()))
        self.body.add(clear)
        self.body.add(WrapLabel(
            "[b]Privacy[/b]\n- Stored on this device: settings, chat history, memories, workspace files, your API key (app-private storage, "
            "not hardware-backed).\n- Sent to the AI provider you choose: your messages in the current conversation, your personality "
            "instructions, enabled memories, and text you ask the AI to process. Nothing is sent in Demo mode.\n"
            "- JARVIS does not record audio in the background, capture the screen, or read other apps. Speech recognition uses Android's "
            "speech service, which may send audio to its provider per your device settings.\n- Logs (off by default) never contain API keys "
            "(redacted) and only record events, not message content.\n\n[b]About[/b]\nJARVIS - Kivy/Python personal AI assistant. No warranty.", 12))

    def on_pre_enter(self, *a):
        c = self.ctx
        self.info.text = (f"Data dir: {c.data_dir}\nOn Android: {c.platform.available}\nProvider: {c.settings.get('provider')} / {c.settings.get('model')}\n"
                          f"Conversations: {len(c.history.list())}  Memories: {len(c.memory.list())}\nTools: {', '.join(c.tools.names())}")
        try:
            tail = c.log_path.read_text(encoding="utf-8").splitlines()[-15:] if c.log_path.exists() else []
        except OSError:
            tail = []
        self.logv.text = "\n".join(tail) or "(log empty or disabled)"
