"""Android integrations via pyjnius. Off-device (or if an API is missing) they report
unavailability honestly instead of pretending success."""
from __future__ import annotations

import os
import webbrowser
from typing import Optional

from security.validation import ValidationError, validate_url

from .registry import ToolRegistry, ToolResult, ToolSpec


class IntegrationUnavailable(Exception):
    pass


SETTINGS_SCREENS = {"main": "ACTION_SETTINGS", "wifi": "ACTION_WIFI_SETTINGS", "bluetooth": "ACTION_BLUETOOTH_SETTINGS",
                    "accessibility": "ACTION_ACCESSIBILITY_SETTINGS", "app": "ACTION_APPLICATION_DETAILS_SETTINGS",
                    "display": "ACTION_DISPLAY_SETTINGS", "sound": "ACTION_SOUND_SETTINGS"}


class AndroidPlatform:
    def __init__(self, force: Optional[bool] = None):
        self.available = ("ANDROID_ARGUMENT" in os.environ) if force is None else force

    def _need(self):
        if not self.available:
            raise IntegrationUnavailable("This feature needs a real Android device.")
        try:
            from jnius import autoclass  # type: ignore
        except Exception as e:
            raise IntegrationUnavailable("pyjnius is not available.") from e
        return autoclass

    def _start(self, intent) -> None:
        autoclass = self._need()
        autoclass("org.kivy.android.PythonActivity").mActivity.startActivity(intent)

    def open_url(self, url: str) -> bool:
        url = validate_url(url)
        if not self.available:
            return bool(webbrowser.open(url))  # desktop convenience
        autoclass = self._need()
        Intent, Uri = autoclass("android.content.Intent"), autoclass("android.net.Uri")
        i = Intent(Intent.ACTION_VIEW)
        i.setData(Uri.parse(url))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        self._start(i)
        return True

    def open_settings(self, screen: str = "main") -> bool:
        if screen not in SETTINGS_SCREENS:
            raise ValidationError("Unknown settings screen.")
        autoclass = self._need()
        Intent, Settings, Uri = (autoclass("android.content.Intent"), autoclass("android.provider.Settings"),
                                 autoclass("android.net.Uri"))
        act = autoclass("org.kivy.android.PythonActivity").mActivity
        i = Intent(getattr(Settings, SETTINGS_SCREENS[screen]))
        if screen == "app":
            i.setData(Uri.parse("package:" + act.getPackageName()))
        self._start(i)
        return True

    def share_text(self, text: str, title: str = "Share via") -> bool:
        autoclass = self._need()
        Intent = autoclass("android.content.Intent")
        i = Intent(Intent.ACTION_SEND)
        i.setType("text/plain")
        i.putExtra(Intent.EXTRA_TEXT, text)
        self._start(Intent.createChooser(i, title))
        return True

    def open_app(self, package: str) -> bool:
        """False if the app is not installed OR not visible to us (Android 11+ package visibility)."""
        autoclass = self._need()
        act = autoclass("org.kivy.android.PythonActivity").mActivity
        intent = act.getPackageManager().getLaunchIntentForPackage(package)
        if intent is None:
            return False
        self._start(intent)
        return True

    @staticmethod
    def copy_text(text: str) -> bool:
        try:
            from kivy.core.clipboard import Clipboard  # type: ignore
            Clipboard.copy(text)
            return True
        except Exception as e:
            raise IntegrationUnavailable("Clipboard unavailable.") from e


def register(reg: ToolRegistry, plat: AndroidPlatform) -> None:
    def wrap(fn, ok_msg):
        def run(**kw):
            try:
                ok = fn(**kw)
            except (IntegrationUnavailable, ValidationError) as e:
                return ToolResult(False, str(e), "failed")
            return ToolResult(bool(ok), ok_msg if ok else "Android could not complete this (app missing or not visible).",
                              "done" if ok else "failed")
        return run

    reg.register(ToolSpec("open_url", "Open an http(s) URL", {"url": str},
                          wrap(plat.open_url, "Asked Android to open the link."), consequential=True))
    reg.register(ToolSpec("open_settings", "Open an Android settings screen", {"screen": str},
                          wrap(plat.open_settings, "Opened settings screen.")))
    reg.register(ToolSpec("copy_text", "Copy text to clipboard", {"text": str},
                          wrap(plat.copy_text, "Copied to clipboard.")))
    reg.register(ToolSpec("share_text", "Share text via the Android Sharesheet", {"text": str},
                          wrap(plat.share_text, "Sharesheet opened. Nothing is sent until you choose an app."),
                          consequential=True))
    reg.register(ToolSpec("open_app", "Launch an installed app", {"package": str},
                          wrap(plat.open_app, "Launched app."), consequential=True))
