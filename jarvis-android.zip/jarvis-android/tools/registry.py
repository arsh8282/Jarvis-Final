"""Permission-aware tool layer. Tools never run AI-generated code; every call is validated,
confirmed when required, and returns an honest result."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from security.secrets import redact

log = logging.getLogger("jarvis.tools")


@dataclass
class ToolResult:
    ok: bool
    message: str
    status: str = "done"  # done | failed | needs_confirmation | cancelled | invalid
    data: Any = None


@dataclass
class ToolSpec:
    name: str
    description: str
    params: dict  # arg name -> type
    handler: Callable[..., ToolResult]
    destructive: bool = False      # always requires confirmation
    consequential: bool = False    # requires confirmation when the setting is on
    preview: Optional[Callable[..., str]] = None
    optional: tuple = ()


class ToolRegistry:
    def __init__(self, confirm_setting: Callable[[], bool]):
        self._tools: dict[str, ToolSpec] = {}
        self._confirm_setting = confirm_setting

    def register(self, spec: ToolSpec) -> None:
        self._tools[spec.name] = spec

    def names(self) -> list[str]:
        return sorted(self._tools)

    def needs_confirmation(self, spec: ToolSpec) -> bool:
        return spec.destructive or (spec.consequential and self._confirm_setting())

    def describe(self, name: str, args: dict) -> str:
        spec = self._tools[name]
        base = f"{spec.name}({', '.join(f'{k}={str(v)[:60]!r}' for k, v in args.items())})"
        if spec.preview:
            try:
                return base + "\n" + spec.preview(**args)
            except Exception as e:  # preview must never crash the flow
                return base + f"\n(preview unavailable: {e})"
        return base

    def execute(self, name: str, args: dict, confirm: Optional[Callable[[str], bool]] = None) -> ToolResult:
        spec = self._tools.get(name)
        if spec is None:
            return ToolResult(False, f"Unknown tool: {name}", "invalid")
        err = self._validate(spec, args)
        if err:
            return ToolResult(False, err, "invalid")
        if self.needs_confirmation(spec):
            if confirm is None:
                return ToolResult(False, "Confirmation required before this action.", "needs_confirmation",
                                  self.describe(name, args))
            if not confirm(self.describe(name, args)):
                return ToolResult(False, "Cancelled by user. Nothing was changed.", "cancelled")
        try:
            res = spec.handler(**args)
        except Exception as e:
            log.warning("tool %s failed: %s", name, redact(str(e)))
            return ToolResult(False, f"{name} failed: {redact(str(e))}", "failed")
        log.info("tool %s -> %s", name, res.status)
        return res

    @staticmethod
    def _validate(spec: ToolSpec, args: dict) -> Optional[str]:
        for k in args:
            if k not in spec.params:
                return f"Unexpected argument: {k}"
        for k, t in spec.params.items():
            if k not in args:
                if k in spec.optional:
                    continue
                return f"Missing argument: {k}"
            if not isinstance(args[k], t) or isinstance(args[k], bool) != (t is bool):
                return f"Argument '{k}' must be {t.__name__}"
        return None
