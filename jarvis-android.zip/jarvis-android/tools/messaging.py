"""Messaging assistance. Opens a prepared draft only; never claims a message was sent."""
from __future__ import annotations

import urllib.parse

from security.validation import ValidationError, normalize_phone

from .android_tools import AndroidPlatform, IntegrationUnavailable
from .registry import ToolRegistry, ToolResult, ToolSpec

MAX_LEN = 4000


def whatsapp_url(phone: str, text: str) -> str:
    digits = normalize_phone(phone)
    if not text.strip():
        raise ValidationError("Message is empty.")
    if len(text) > MAX_LEN:
        raise ValidationError("Message is too long.")
    return f"https://wa.me/{digits}?text={urllib.parse.quote(text)}"


def register(reg: ToolRegistry, plat: AndroidPlatform) -> None:
    def run(phone: str, text: str) -> ToolResult:
        try:
            url = whatsapp_url(phone, text)
            plat.open_url(url)
        except (ValidationError, IntegrationUnavailable) as e:
            return ToolResult(False, str(e), "failed")
        return ToolResult(True, "WhatsApp (or your browser) was opened with the draft. "
                                "The message is NOT sent until you press Send there.")

    reg.register(ToolSpec("whatsapp_draft", "Open WhatsApp with a prepared draft", {"phone": str, "text": str},
                          run, consequential=True,
                          preview=lambda phone, text: f"To: +{normalize_phone(phone)}\n\n{text}"))
