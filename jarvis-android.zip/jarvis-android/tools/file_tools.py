from __future__ import annotations

from editor.workspace import Workspace, WorkspaceError

from .registry import ToolResult, ToolRegistry, ToolSpec


def register(reg: ToolRegistry, ws: Workspace) -> None:
    def guard(fn):
        def run(**kw):
            try:
                return fn(**kw)
            except WorkspaceError as e:
                return ToolResult(False, str(e), "failed")
        return run

    reg.register(ToolSpec("list_dir", "List a workspace directory", {"path": str},
                          guard(lambda path: ToolResult(True, f"{len(ws.list_dir(path))} entries", data=ws.list_dir(path)))))
    reg.register(ToolSpec("read_file", "Read a workspace file", {"path": str},
                          guard(lambda path: ToolResult(True, "Read OK", data=ws.read_text(path)))))
    reg.register(ToolSpec("write_file", "Create or overwrite a workspace file (backup kept)",
                          {"path": str, "content": str},
                          guard(lambda path, content: ToolResult(
                              True, "Saved" + (" (previous version backed up)" if ws.resolve(path).exists() else ""),
                              data=ws.write_text(path, content))),
                          consequential=True, preview=lambda path, content: ws.preview_write(path, content)))
    reg.register(ToolSpec("rename_file", "Rename or move a workspace file", {"src": str, "dst": str},
                          guard(lambda src, dst: ToolResult(True, f"Renamed to {ws.rename(src, dst)}")),
                          consequential=True))
    reg.register(ToolSpec("delete_file", "Delete a file (recoverable from backups)", {"path": str},
                          guard(lambda path: ToolResult(True, f"Deleted; backup {ws.delete(path)}")), destructive=True))
    reg.register(ToolSpec("search_files", "Search text in workspace files", {"query": str},
                          guard(lambda query: ToolResult(True, "Search done", data=ws.search(query)))))
