from __future__ import annotations

from typing import Optional

from providers.base import ChatMessage
from storage.history import HistoryStore


class Conversation:
    """Shared by text and voice mode. Persists to SQLite only when history is enabled."""

    def __init__(self, history: HistoryStore, persist: bool, conv_id: Optional[int] = None):
        self.history, self.persist = history, persist
        self.id = conv_id
        self.messages: list[ChatMessage] = []
        if conv_id is not None:
            self.messages = [ChatMessage(m["role"], m["content"]) for m in history.messages(conv_id)]

    def add(self, role: str, content: str) -> None:
        self.messages.append(ChatMessage(role, content))
        if self.persist:
            if self.id is None:
                title = content.strip().splitlines()[0][:50] if content.strip() else "New conversation"
                self.id = self.history.create(title)
            self.history.add_message(self.id, role, content)

    def pop_last(self, role: str) -> Optional[ChatMessage]:
        if self.messages and self.messages[-1].role == role:
            m = self.messages.pop()
            if self.persist and self.id is not None:
                self.history.delete_last(self.id, role)
            return m
        return None
