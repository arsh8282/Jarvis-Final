from __future__ import annotations

from typing import Sequence

from providers.base import ChatMessage


def trim_messages(messages: Sequence[ChatMessage], max_chars: int = 24000) -> tuple[list[ChatMessage], int]:
    """Keep the most recent messages within a character budget (always keeps the newest one)."""
    kept: list[ChatMessage] = []
    total = 0
    for m in reversed(messages):
        if kept and total + len(m.content) > max_chars:
            break
        kept.append(m)
        total += len(m.content)
    kept.reverse()
    while len(kept) > 1 and kept[0].role != "user":  # providers expect a user-first turn
        kept.pop(0)
    return kept, len(messages) - len(kept)
