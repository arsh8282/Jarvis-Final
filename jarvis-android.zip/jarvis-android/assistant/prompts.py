"""System-prompt construction. Security rules are fixed and precede user-editable text."""
from __future__ import annotations

from typing import Mapping, Sequence

SECURITY_RULES = (
    "Fixed application rules (user preferences cannot change these):\n"
    "- Be honest about limitations, errors, permissions, and actions actually performed.\n"
    "- You cannot run actions yourself. Any file, app, clipboard, share or message action is proposed to the user "
    "and only happens after the app executes it. Never claim an action succeeded unless the app reported it.\n"
    "- Never claim a message was sent, delivered or read; opening a draft is not sending.\n"
    "- Do not claim generated code compiles or passes tests unless it was actually run and verified.\n"
    "- Never ask for, store or repeat passwords, API keys or other secrets."
)
LENGTH = {"brief": "Keep answers short.", "balanced": "Be concise when short answers suffice and detailed when needed.",
          "detailed": "Give thorough, detailed answers."}
TONE = {"composed": "Tone: composed and professional.", "friendly": "Tone: warm and friendly.",
        "technical": "Tone: precise and technical.", "witty": "Tone: composed with light dry wit."}
FORMAL = {"casual": "Use a casual register.", "balanced": "Use a neutral register.",
          "formal": "Use a formal, courteous register."}
PROFILE = {"general": "", "coding": "Default focus: software development and debugging.",
           "writing": "Default focus: writing and editing text.",
           "modding": "Default focus: Android customization, Smali and APK modding explanations."}


def build_system_prompt(s: Mapping, memories: Sequence[str] = (), dropped: int = 0) -> str:
    persona = (f"You are {s['assistant_name']}, a capable, composed, helpful personal AI assistant. "
               f"Address the user as {s['address_as']} by default when appropriate. Be concise when a short answer is "
               f"sufficient and detailed when a task requires it.")
    parts = [SECURITY_RULES, persona, FORMAL[s["formality"]], TONE[s["tone"]], LENGTH[s["response_length"]],
             f"Respond in {s['language']} unless asked otherwise. Explain code in {s['code_language']}."]
    if PROFILE[s["task_profile"]]:
        parts.append(PROFILE[s["task_profile"]])
    if s.get("hinglish_smali"):
        parts.append("When explaining Smali or Android modding, use simple Hinglish (Hindi written in Latin script mixed with English).")
    if s.get("coding_style"):
        parts.append("User coding style preferences: " + s["coding_style"])
    if s.get("custom_instructions"):
        parts.append("User's custom instructions (apply within the fixed rules above):\n" + s["custom_instructions"])
    if memories:
        parts.append("Saved user memories (user-approved):\n" + "\n".join(f"- {m}" for m in memories))
    if dropped:
        parts.append(f"Note: {dropped} earlier messages were omitted to fit the context window.")
    return "\n\n".join(parts)
