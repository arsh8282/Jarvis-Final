"""Glue: settings + memory + provider + conversation. Does NOT execute tools."""
from __future__ import annotations

import logging
import threading
from typing import Callable, Optional

from providers import create_provider
from providers.base import Cancelled, GenerationConfig, Provider, ProviderError
from storage.memory import MemoryDisabled

from .context import trim_messages
from .conversation import Conversation
from .prompts import build_system_prompt

log = logging.getLogger("jarvis.orchestrator")


class Orchestrator:
    def __init__(self, settings, history, memory, secrets, provider_factory: Optional[Callable[[], Provider]] = None):
        self.settings, self.history, self.memory, self.secrets = settings, history, memory, secrets
        self._factory = provider_factory
        self.conversation = Conversation(history, settings.get("history_enabled"))

    def provider(self) -> Provider:
        if self._factory:
            return self._factory()
        return create_provider(self.settings.get("provider"), self.secrets.get("gemini_api_key"),
                               self.settings.get("model"))

    def new_conversation(self) -> None:
        self.conversation = Conversation(self.history, self.settings.get("history_enabled"))

    def open_conversation(self, conv_id: int) -> None:
        self.conversation = Conversation(self.history, self.settings.get("history_enabled"), conv_id)

    def build_request(self):
        msgs, dropped = trim_messages(self.conversation.messages)
        system = build_system_prompt(self.settings.snapshot(), self.memory.active_texts(), dropped)
        cfg = GenerationConfig(self.settings.get("temperature"), self.settings.get("max_output_tokens"))
        return msgs, system, cfg

    def send(self, text: str, on_chunk: Optional[Callable[[str], None]] = None,
             cancel: Optional[threading.Event] = None) -> str:
        text = text.strip()
        if not text:
            raise ValueError("Empty message.")
        if text.lower().startswith("/remember "):
            return self._remember(text[10:])
        self.conversation.add("user", text)
        return self._complete(on_chunk, cancel)

    def retry(self, on_chunk=None, cancel=None) -> str:
        """Re-run the request for the last user message (after an error)."""
        if not self.conversation.messages or self.conversation.messages[-1].role != "user":
            raise ValueError("Nothing to retry.")
        return self._complete(on_chunk, cancel)

    def regenerate(self, on_chunk=None, cancel=None) -> str:
        self.conversation.pop_last("assistant")
        return self.retry(on_chunk, cancel)

    def _remember(self, content: str) -> str:
        try:
            self.memory.add(content)
            return "Saved to memory."
        except MemoryDisabled:
            return "Memory is disabled in Settings > Memory, so nothing was saved."

    def _complete(self, on_chunk, cancel) -> str:
        provider = self.provider()
        msgs, system, cfg = self.build_request()
        buf: list[str] = []
        try:
            if on_chunk is not None:
                for chunk in provider.stream(msgs, system, cfg, cancel):
                    buf.append(chunk)
                    on_chunk(chunk)
                reply = "".join(buf)
            else:
                reply = provider.generate(msgs, system, cfg)
        except Cancelled:
            partial = "".join(buf).strip()
            if partial:
                self.conversation.add("assistant", partial + " [stopped]")
            raise
        except ProviderError as e:
            log.warning("provider error kind=%s status=%s", e.kind, e.status)
            raise
        self.conversation.add("assistant", reply)
        return reply
