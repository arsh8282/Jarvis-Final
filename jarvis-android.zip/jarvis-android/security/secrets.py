"""Secret storage and log redaction.

LIMITATION (documented in README): secrets are stored in the app-private directory
(Android sandbox, file mode 0600). They are NOT hardware-backed Android Keystore entries.
"""
from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Optional

_BEARER = re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]+")
_GKEY = re.compile(r"AIza[0-9A-Za-z_\-]{20,}")
_KV = re.compile(r"(?i)(api[_-]?key|x-goog-api-key|token|authorization|password|secret)(\"?\s*[:=]\s*\"?)([^\s\"&,}]+)")


def redact(text: str) -> str:
    text = _BEARER.sub("Bearer [REDACTED]", str(text))
    text = _GKEY.sub("[REDACTED]", text)
    return _KV.sub(lambda m: m.group(1) + m.group(2) + "[REDACTED]", text)


def mask_key(key: str) -> str:
    if not key:
        return ""
    return "\u2022" * 8 if len(key) <= 8 else f"{key[:3]}\u2022\u2022\u2022\u2022{key[-2:]}"


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = redact(record.getMessage())
        record.args = ()
        return True


class SecretStore:
    def __init__(self, path):
        self.path = Path(path)

    def _read(self) -> dict:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def get(self, name: str) -> str:
        return self._read().get(name, "")

    def has(self, name: str) -> bool:
        return bool(self.get(name))

    def set(self, name: str, value: str) -> None:
        data = self._read()
        if value:
            data[name] = value
        else:
            data.pop(name, None)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, self.path)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def delete(self, name: str) -> None:
        self.set(name, "")
