"""Real Android permission status (never assumed). Returns 'not_applicable' off-device."""
from __future__ import annotations

import os

KNOWN = {
    "RECORD_AUDIO": "Microphone: needed for speech-to-text (push-to-talk).",
    "INTERNET": "Network: needed to reach the AI provider (granted at install).",
}


def on_android() -> bool:
    return "ANDROID_ARGUMENT" in os.environ


def check(name: str) -> str:
    if name == "INTERNET":
        return "granted" if on_android() else "not_applicable"
    if not on_android():
        return "not_applicable"
    try:
        from android.permissions import Permission, check_permission  # type: ignore
        return "granted" if check_permission(getattr(Permission, name)) else "denied"
    except Exception:
        return "unknown"


def request(names: list[str], callback=None) -> bool:
    if not on_android():
        return False
    try:
        from android.permissions import Permission, request_permissions  # type: ignore
        request_permissions([getattr(Permission, n) for n in names], callback)
        return True
    except Exception:
        return False


def status_report() -> list[dict]:
    return [{"name": n, "purpose": p, "status": check(n)} for n, p in KNOWN.items()]
