"""Input validation: paths, URLs, phone numbers, structured formats."""
from __future__ import annotations

import json
import re
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath


class ValidationError(ValueError):
    pass


def safe_resolve(root, rel: str) -> Path:
    """Resolve `rel` inside `root`; reject absolute paths, '..', NULs and symlink escapes."""
    if not isinstance(rel, str) or "\x00" in rel:
        raise ValidationError("Invalid path.")
    rel = rel.replace("\\", "/")
    if rel.startswith("/") or re.match(r"^[A-Za-z]:", rel):
        raise ValidationError("Absolute paths are not allowed.")
    if ".." in PurePosixPath(rel).parts:
        raise ValidationError("Path traversal ('..') is not allowed.")
    root_p = Path(root).resolve()
    target = (root_p / rel).resolve()
    try:
        target.relative_to(root_p)
    except ValueError:
        raise ValidationError("Path escapes the authorized workspace.") from None
    return target


def validate_url(url: str) -> str:
    u = urllib.parse.urlparse((url or "").strip())
    if u.scheme not in ("http", "https") or not u.netloc:
        raise ValidationError("Only http(s) URLs with a host are allowed.")
    return url.strip()


def normalize_phone(raw: str) -> str:
    """Return digits in international format (no '+'), or raise."""
    digits = re.sub(r"[\s\-().]", "", raw or "")
    if digits.startswith("+"):
        digits = digits[1:]
    if not digits.isdigit() or not (7 <= len(digits) <= 15) or digits.startswith("0"):
        raise ValidationError("Enter the number with country code, e.g. +919876543210.")
    return digits


def validate_json(text: str) -> str:
    try:
        json.loads(text)
        return "Valid JSON."
    except json.JSONDecodeError as e:
        raise ValidationError(f"Invalid JSON at line {e.lineno}, column {e.colno}: {e.msg}") from None


def validate_xml(text: str) -> str:
    try:
        ET.fromstring(text)
        return "Well-formed XML."
    except ET.ParseError as e:
        raise ValidationError(f"Invalid XML: {e}") from None
