import tempfile
import unittest
from pathlib import Path

from assistant.context import trim_messages
from assistant.orchestrator import Orchestrator
from assistant.prompts import SECURITY_RULES, build_system_prompt
from providers import MockProvider
from providers.base import ChatMessage, ProviderError
from security.secrets import SecretStore
from settings import DEFAULTS, SettingsManager
from storage import Database, HistoryStore, MemoryDisabled, MemoryStore


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.h = HistoryStore(self.db)
        self.enabled = False
        self.mem = MemoryStore(self.db, lambda: self.enabled)

    def test_history_crud_search_export(self):
        c = self.h.create("Plans")
        self.h.add_message(c, "user", "Build a rocket")
        self.h.add_message(c, "assistant", "Sure")
        self.assertEqual(len(self.h.messages(c)), 2)
        self.assertEqual([x["id"] for x in self.h.list("rocket")], [c])
        self.assertEqual(self.h.list("zzz"), [])
        self.h.rename(c, "Rocket")
        self.assertEqual(self.h.title(c), "Rocket")
        self.assertIn("Build a rocket", self.h.export_json(c))
        self.assertIn("# Rocket", self.h.export_markdown(c))
        self.h.delete(c)
        self.assertEqual(self.h.messages(c), [])  # cascade
        with self.assertRaises(ValueError):
            self.h.rename(self.h.create("x"), "  ")

    def test_memory_disabled_saves_nothing(self):
        with self.assertRaises(MemoryDisabled):
            self.mem.add("likes tea")
        self.assertEqual(self.mem.list(), [])

    def test_memory_enabled_edit_delete_and_prompt_injection_only_when_enabled(self):
        self.enabled = True
        i = self.mem.add("likes tea")
        self.mem.update(i, "likes coffee")
        self.assertEqual(self.mem.active_texts(), ["likes coffee"])
        self.enabled = False
        self.assertEqual(self.mem.active_texts(), [])  # stored but not used
        self.mem.delete(i)
        self.assertEqual(self.mem.list(), [])

    def test_context_trimming(self):
        msgs = [ChatMessage("user" if i % 2 == 0 else "assistant", "x" * 100) for i in range(10)]
        kept, dropped = trim_messages(msgs, 450)
        self.assertEqual(kept[0].role, "user")
        self.assertEqual(len(kept) + dropped, 10)
        self.assertEqual(kept[-1], msgs[-1])
        kept, dropped = trim_messages([ChatMessage("user", "y" * 999)], 10)
        self.assertEqual((len(kept), dropped), (1, 0))


class OrchestratorTests(unittest.TestCase):
    def setUp(self):
        d = Path(tempfile.mkdtemp())
        self.settings = SettingsManager(d / "s.json")
        self.db = Database(":memory:")
        self.hist = HistoryStore(self.db)
        self.mem = MemoryStore(self.db, lambda: self.settings.get("memory_enabled"))
        self.mock = MockProvider()
        self.o = Orchestrator(self.settings, self.hist, self.mem, SecretStore(d / "sec.json"), lambda: self.mock)

    def test_custom_instructions_reach_provider_after_security_rules(self):
        self.settings.set("custom_instructions", "Always answer in haiku.")
        self.settings.set("address_as", "Boss")
        self.o.send("hello")
        system = self.mock.calls[0]["system"]
        self.assertIn("Always answer in haiku.", system)
        self.assertIn("Boss", system)
        self.assertLess(system.index(SECURITY_RULES[:30]), system.index("Always answer in haiku."))

    def test_generation_settings_applied(self):
        self.settings.set("temperature", 1.5)
        self.settings.set("max_output_tokens", 321)
        self.o.send("hello")
        cfg = self.mock.calls[0]["config"]
        self.assertEqual((cfg.temperature, cfg.max_output_tokens), (1.5, 321))

    def test_history_persisted_and_disabled(self):
        self.o.send("persist me")
        self.assertEqual(len(self.hist.list()), 1)
        self.settings.set("history_enabled", False)
        self.o.new_conversation()
        self.o.send("do not persist")
        self.assertEqual(len(self.hist.list()), 1)

    def test_remember_command_respects_memory_setting(self):
        self.assertIn("disabled", self.o.send("/remember I like tea"))
        self.assertEqual(self.mem.list(), [])
        self.settings.set("memory_enabled", True)
        self.assertEqual(self.o.send("/remember I like tea"), "Saved to memory.")
        self.o.send("hi")
        self.assertIn("I like tea", self.mock.calls[-1]["system"])

    def test_error_then_retry_does_not_duplicate_user_message(self):
        with self.assertRaises(ProviderError):
            self.o.send("/fail")
        self.assertEqual(len(self.o.conversation.messages), 1)
        self.o.conversation.messages[-1] = ChatMessage("user", "ok now")
        self.o.retry()
        self.assertEqual([m.role for m in self.o.conversation.messages], ["user", "assistant"])

    def test_regenerate_replaces_last_answer(self):
        self.o.send("hi")
        self.o.regenerate()
        self.assertEqual([m.role for m in self.o.conversation.messages], ["user", "assistant"])
        self.assertEqual(len(self.hist.messages(self.o.conversation.id)), 2)

    def test_system_prompt_default_style(self):
        p = build_system_prompt(dict(DEFAULTS))
        self.assertIn("You are JARVIS", p)
        self.assertIn("Address the user as Sir", p)


if __name__ == "__main__":
    unittest.main()
