import tempfile
import unittest
from pathlib import Path

from editor.workspace import Workspace
from tools import android_tools, file_tools, messaging
from tools.android_tools import AndroidPlatform
from tools.registry import ToolRegistry
from voice.speech_output import to_spoken
from ui import markup


class ToolTests(unittest.TestCase):
    def setUp(self):
        self.ws = Workspace(Path(tempfile.mkdtemp()) / "w")
        self.confirm_on = True
        self.reg = ToolRegistry(lambda: self.confirm_on)
        self.plat = AndroidPlatform(force=False)  # simulate missing Android APIs
        file_tools.register(self.reg, self.ws)
        android_tools.register(self.reg, self.plat)
        messaging.register(self.reg, self.plat)

    def test_write_requires_confirmation_and_nothing_changes_without_it(self):
        r = self.reg.execute("write_file", {"path": "a.txt", "content": "hi"})
        self.assertEqual(r.status, "needs_confirmation")
        self.assertIn("+hi", r.data)  # preview diff shown
        self.assertFalse((self.ws.root / "a.txt").exists())
        r = self.reg.execute("write_file", {"path": "a.txt", "content": "hi"}, confirm=lambda d: False)
        self.assertEqual(r.status, "cancelled")
        self.assertFalse((self.ws.root / "a.txt").exists())
        r = self.reg.execute("write_file", {"path": "a.txt", "content": "hi"}, confirm=lambda d: True)
        self.assertTrue(r.ok)
        self.assertEqual(self.ws.read_text("a.txt"), "hi")

    def test_destructive_always_confirms_even_if_setting_off(self):
        self.ws.write_text("a.txt", "x")
        self.confirm_on = False
        self.assertEqual(self.reg.execute("delete_file", {"path": "a.txt"}).status, "needs_confirmation")
        self.assertTrue((self.ws.root / "a.txt").exists())
        self.assertTrue(self.reg.execute("delete_file", {"path": "a.txt"}, confirm=lambda d: True).ok)
        # consequential write needs no prompt when the setting is off
        self.assertTrue(self.reg.execute("write_file", {"path": "b.txt", "content": "1"}).ok)

    def test_argument_validation(self):
        self.assertEqual(self.reg.execute("read_file", {}).status, "invalid")
        self.assertEqual(self.reg.execute("read_file", {"path": 5}).status, "invalid")
        self.assertEqual(self.reg.execute("read_file", {"path": "a", "x": 1}).status, "invalid")
        self.assertEqual(self.reg.execute("rm_rf", {}).status, "invalid")

    def test_traversal_blocked_through_tools(self):
        r = self.reg.execute("read_file", {"path": "../../etc/passwd"})
        self.assertFalse(r.ok)
        self.assertEqual(r.status, "failed")

    def test_android_tools_fail_honestly_without_android(self):
        r = self.reg.execute("share_text", {"text": "x"}, confirm=lambda d: True)
        self.assertFalse(r.ok)
        self.assertIn("Android", r.message)
        r = self.reg.execute("open_settings", {"screen": "wifi"})
        self.assertFalse(r.ok)

    def test_whatsapp_draft_never_claims_sent(self):
        url = messaging.whatsapp_url("+91 98765 43210", "Hi there & bye")
        self.assertTrue(url.startswith("https://wa.me/919876543210?text=Hi%20there%20%26%20bye"))
        bad = self.reg.execute("whatsapp_draft", {"phone": "12", "text": "x"}, confirm=lambda d: True)
        self.assertFalse(bad.ok)
        calls = []
        self.plat.open_url = lambda u: calls.append(u) or True
        r = self.reg.execute("whatsapp_draft", {"phone": "+919876543210", "text": "Hello"}, confirm=lambda d: True)
        self.assertTrue(r.ok)
        self.assertIn("NOT sent", r.message)
        self.assertEqual(len(calls), 1)
        self.assertEqual(self.reg.execute("whatsapp_draft", {"phone": "+919876543210", "text": "Hello"}).status,
                         "needs_confirmation")


class MiscTests(unittest.TestCase):
    def test_spoken_text(self):
        t = "# Title\nFirst sentence. Second one. Third one.\n```py\nprint(1)\n```"
        s = to_spoken(t, "short")
        self.assertNotIn("print", s)
        self.assertEqual(to_spoken("A. B. C. D.", "short"), "A. B.")
        self.assertIn("(code omitted)", to_spoken(t, "full"))

    def test_markup_escapes_and_blocks(self):
        out = markup.render("Use [b]x[/b] **bold**\n```python\nx = 'a'  # c\n```")
        self.assertIn("&bl;b&br;", out)
        self.assertIn("[b]bold[/b]", out)
        self.assertIn("RobotoMono", out)
        self.assertEqual(markup.code_blocks("```py\nA\n```\n```\nB\n```"), ["A\n", "B\n"])

    def test_missing_speech_apis_do_not_crash(self):
        from voice.speech_input import SpeechInput
        from voice.speech_output import SpeechOutput
        i, o = SpeechInput(), SpeechOutput()
        self.assertFalse(i.available)
        self.assertTrue(i.start())  # returns an error string
        self.assertFalse(o.speak("hello"))

    def test_app_context_headless(self):
        from app_context import AppContext
        c = AppContext(tempfile.mkdtemp())
        reply = c.orch.send("hello")
        self.assertIn("Demo mode", reply)
        c.settings.set("workspace_dir", str(Path(tempfile.mkdtemp()) / "other"))
        self.assertTrue(c.tools.execute("write_file", {"path": "z.txt", "content": "1"}, confirm=lambda d: True).ok)
        self.assertTrue((Path(c.settings.get("workspace_dir")) / "z.txt").exists())
        c.close()


if __name__ == "__main__":
    unittest.main()
