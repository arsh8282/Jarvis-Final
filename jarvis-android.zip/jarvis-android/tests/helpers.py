import json


class FakeTransport:
    """Scripted transport: responses is a list of (status, body_or_lines)."""

    def __init__(self, responses):
        self.responses, self.calls = list(responses), []

    def request(self, method, url, headers, body, timeout=0):
        self.calls.append({"method": method, "url": url, "headers": headers, "body": body})
        status, text = self.responses.pop(0)
        return status, text if isinstance(text, str) else json.dumps(text)

    def stream_lines(self, method, url, headers, body, timeout=0):
        self.calls.append({"method": method, "url": url, "headers": headers, "body": body})
        status, lines = self.responses.pop(0)
        return status, iter(lines if isinstance(lines, list) else [lines])


def ok_body(text):
    return {"candidates": [{"content": {"parts": [{"text": text}]}, "finishReason": "STOP"}],
            "usageMetadata": {"totalTokenCount": 7}}
