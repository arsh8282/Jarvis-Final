import threading
import unittest

from providers import GeminiProvider, MockProvider, create_provider
from providers.base import Cancelled, ChatMessage, GenerationConfig, ProviderError
from tests.helpers import FakeTransport, ok_body

MSGS = [ChatMessage("user", "hi"), ChatMessage("assistant", "hello"), ChatMessage("user", "again")]
CFG = GenerationConfig(0.3, 100)


class GeminiTests(unittest.TestCase):
    def mk(self, responses, **kw):
        t = FakeTransport(responses)
        return GeminiProvider("AIzaFAKEFAKEFAKEFAKEFAKEFAKE", "gemini-x", transport=t, sleep=lambda s: None, **kw), t

    def test_request_construction(self):
        p, _ = self.mk([])
        body = p.build_request(MSGS, "SYS", CFG)
        self.assertEqual([c["role"] for c in body["contents"]], ["user", "model", "user"])
        self.assertEqual(body["systemInstruction"]["parts"][0]["text"], "SYS")
        self.assertEqual(body["generationConfig"], {"temperature": 0.3, "maxOutputTokens": 100})

    def test_key_in_header_not_url(self):
        p, t = self.mk([(200, ok_body("yo"))])
        self.assertEqual(p.generate(MSGS, "", CFG), "yo")
        call = t.calls[0]
        self.assertNotIn("AIza", call["url"])
        self.assertIn("gemini-x:generateContent", call["url"])
        self.assertEqual(call["headers"]["x-goog-api-key"], "AIzaFAKEFAKEFAKEFAKEFAKEFAKE")
        self.assertEqual(p.last_usage, {"totalTokenCount": 7})

    def test_error_mapping_no_retry_for_auth(self):
        for status, kind in [(401, "auth"), (403, "auth"), (404, "model_not_found"), (400, "bad_request")]:
            p, t = self.mk([(status, {"error": {"message": "x"}}), (200, ok_body("never"))])
            with self.assertRaises(ProviderError) as cm:
                p.generate(MSGS, "", CFG)
            self.assertEqual(cm.exception.kind, kind)
            self.assertEqual(len(t.calls), 1)  # no retry

    def test_retry_then_success_and_limit(self):
        p, t = self.mk([(503, "{}"), (429, "{}"), (200, ok_body("late"))])
        self.assertEqual(p.generate(MSGS, "", CFG), "late")
        self.assertEqual(len(t.calls), 3)
        p, t = self.mk([(503, "{}")] * 5)
        with self.assertRaises(ProviderError) as cm:
            p.generate(MSGS, "", CFG)
        self.assertEqual(cm.exception.kind, "server")
        self.assertEqual(len(t.calls), 3)  # 1 + 2 retries, bounded

    def test_missing_key_makes_no_request(self):
        t = FakeTransport([])
        p = GeminiProvider("", transport=t)
        with self.assertRaises(ProviderError) as cm:
            p.generate(MSGS, "", CFG)
        self.assertEqual(cm.exception.kind, "auth")
        self.assertEqual(t.calls, [])

    def test_blocked_prompt(self):
        p, _ = self.mk([(200, {"promptFeedback": {"blockReason": "SAFETY"}})])
        with self.assertRaises(ProviderError) as cm:
            p.generate(MSGS, "", CFG)
        self.assertEqual(cm.exception.kind, "blocked")

    def test_streaming_and_cancel(self):
        lines = ["data: " + '{"candidates":[{"content":{"parts":[{"text":"A"}]}}]}', "",
                 "data: " + '{"candidates":[{"content":{"parts":[{"text":"B"}]}}]}']
        p, t = self.mk([(200, lines)])
        self.assertEqual("".join(p.stream(MSGS, "", CFG)), "AB")
        self.assertIn("streamGenerateContent?alt=sse", t.calls[0]["url"])
        p, _ = self.mk([(200, lines)])
        ev = threading.Event()
        ev.set()
        with self.assertRaises(Cancelled):
            list(p.stream(MSGS, "", CFG, ev))

    def test_list_models_filters(self):
        body = {"models": [{"name": "models/a", "supportedGenerationMethods": ["generateContent"]},
                           {"name": "models/emb", "supportedGenerationMethods": ["embedContent"]}]}
        p, _ = self.mk([(200, body)])
        self.assertEqual(p.list_models(), ["a"])


class MockTests(unittest.TestCase):
    def test_mock_generates_and_streams_offline(self):
        m = MockProvider()
        self.assertIn("hi", m.generate([ChatMessage("user", "hi")], "", CFG))
        self.assertIn("hi", "".join(m.stream([ChatMessage("user", "hi")], "", CFG)))

    def test_mock_failure_simulation(self):
        with self.assertRaises(ProviderError):
            MockProvider().generate([ChatMessage("user", "/fail")], "", CFG)

    def test_factory(self):
        self.assertIsInstance(create_provider("mock"), MockProvider)
        self.assertIsInstance(create_provider("gemini", "k", "m"), GeminiProvider)


if __name__ == "__main__":
    unittest.main()
