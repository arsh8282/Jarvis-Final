import configparser
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class ProjectConfigTests(unittest.TestCase):
    def test_buildozer_spec(self):
        cp = configparser.ConfigParser(interpolation=None)
        cp.read(ROOT / "buildozer.spec")
        app = cp["app"]
        self.assertEqual(app["title"], "JARVIS")
        perms = {p.strip() for p in app["android.permissions"].split(",")}
        self.assertEqual(perms, {"INTERNET", "RECORD_AUDIO"})  # no broad storage permissions
        for req in ("kivy==2.3.0", "pyjnius", "sqlite3", "openssl", "certifi", "plyer==2.1.0"):
            self.assertIn(req, app["requirements"])
        self.assertEqual(app["android.allow_backup"], "False")

    def test_workflows_exist_and_least_privilege(self):
        for name in ("android-build.yml", "tests.yml"):
            text = (ROOT / ".github" / "workflows" / name).read_text()
            self.assertIn("permissions:\n  contents: read", text)
            self.assertNotIn("secrets.", text)
            self.assertNotRegex(text, r"@(master|main|latest)\b")
        b = (ROOT / ".github" / "workflows" / "android-build.yml").read_text()
        self.assertIn("buildozer -v android debug", b)
        self.assertIn("upload-artifact@v4", b)
        self.assertIn("needs: test", b)

    def test_no_committed_secrets(self):
        pat = re.compile(r"AIza[0-9A-Za-z_\-]{30,}|-----BEGIN [A-Z ]*PRIVATE KEY-----")
        for p in ROOT.rglob("*"):
            if p.is_file() and p.suffix in {".py", ".json", ".yml", ".md", ".spec", ".txt"} and ".git" not in p.parts:
                self.assertIsNone(pat.search(p.read_text(errors="ignore")), str(p))

    def test_gitignore_covers_sensitive_files(self):
        gi = (ROOT / ".gitignore").read_text()
        for item in ("*.keystore", "secrets.json", ".buildozer/", "*.apk", "*.db"):
            self.assertIn(item, gi)


if __name__ == "__main__":
    unittest.main()
