import json
import tempfile
import unittest
from pathlib import Path

from settings import DEFAULTS, SettingsManager, validate_value


class SettingsTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.path = self.dir / "s.json"

    def test_defaults_and_persistence(self):
        s = SettingsManager(self.path)
        self.assertEqual(s.get("theme"), DEFAULTS["theme"])
        s.set("theme", "light")
        s.set("temperature", 1.2)
        s2 = SettingsManager(self.path)
        self.assertEqual(s2.get("theme"), "light")
        self.assertEqual(s2.get("temperature"), 1.2)

    def test_validation_rejects_bad_values(self):
        s = SettingsManager(self.path)
        for key, bad in [("theme", "neon"), ("temperature", 9), ("max_output_tokens", 1.5), ("confirm_actions", "yes"),
                         ("assistant_name", "x" * 100), ("assistant_name", "a\nb"), ("nope", 1), ("voice_rate", True)]:
            with self.assertRaises(ValueError, msg=key):
                s.set(key, bad)
        self.assertEqual(s.get("theme"), "dark")

    def test_corrupt_file_falls_back_to_defaults(self):
        self.path.write_text("{not json")
        s = SettingsManager(self.path)
        self.assertEqual(s.get("provider"), "mock")
        self.assertTrue(self.path.with_suffix(".corrupt").exists())

    def test_invalid_persisted_value_ignored(self):
        self.path.write_text(json.dumps({"theme": "neon", "font_scale": 1.3}))
        s = SettingsManager(self.path)
        self.assertEqual(s.get("theme"), "dark")
        self.assertEqual(s.get("font_scale"), 1.3)

    def test_reset_and_listener(self):
        s = SettingsManager(self.path)
        seen = []
        s.subscribe(lambda k, v: seen.append((k, v)))
        s.set("custom_instructions", "be terse")
        s.reset(["custom_instructions"])
        self.assertEqual(s.get("custom_instructions"), "")
        self.assertEqual(seen[0], ("custom_instructions", "be terse"))

    def test_text_trimmed(self):
        self.assertEqual(validate_value("address_as", "  Boss "), "Boss")


if __name__ == "__main__":
    unittest.main()
