import os
import stat
import tempfile
import unittest
from pathlib import Path

from security.secrets import SecretStore, mask_key, redact
from security.validation import (ValidationError, normalize_phone, safe_resolve, validate_json, validate_url,
                                 validate_xml)


class RedactionTests(unittest.TestCase):
    def test_redacts_google_key_and_headers(self):
        k = "AI" + "zaSyA1234567890abcdefghijklmnopqrstu"
        self.assertNotIn(k, redact(f"failed with key {k}"))
        self.assertNotIn("sekret", redact("x-goog-api-key: sekret"))
        self.assertNotIn("abc123", redact("Authorization: Bearer abc123"))
        self.assertNotIn("hunter2", redact('{"password": "hunter2"}'))
        self.assertEqual(redact("plain text"), "plain text")

    def test_mask(self):
        self.assertEqual(mask_key(""), "")
        self.assertNotIn("1234567890", mask_key("AIza1234567890xyz"))
        self.assertEqual(len(set(mask_key("short"))), 1)

    def test_secret_store_roundtrip_and_perms(self):
        p = Path(tempfile.mkdtemp()) / "s.json"
        s = SecretStore(p)
        self.assertFalse(s.has("k"))
        s.set("k", "v")
        self.assertEqual(SecretStore(p).get("k"), "v")
        if os.name == "posix":
            self.assertEqual(stat.S_IMODE(p.stat().st_mode), 0o600)
        s.delete("k")
        self.assertFalse(s.has("k"))


class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp())

    def test_traversal_rejected(self):
        for bad in ["../x", "a/../../x", "/etc/passwd", "C:\\win", "a\x00b", "..\\x"]:
            with self.assertRaises(ValidationError, msg=bad):
                safe_resolve(self.root, bad)

    def test_symlink_escape_rejected(self):
        outside = Path(tempfile.mkdtemp())
        try:
            os.symlink(outside, self.root / "link")
        except (OSError, NotImplementedError):
            self.skipTest("symlinks unsupported")
        with self.assertRaises(ValidationError):
            safe_resolve(self.root, "link/secret.txt")

    def test_valid_path(self):
        self.assertEqual(safe_resolve(self.root, "a/b.txt"), self.root.resolve() / "a" / "b.txt")

    def test_url_and_phone(self):
        self.assertEqual(validate_url("https://a.com/x"), "https://a.com/x")
        for bad in ["javascript:alert(1)", "file:///etc/passwd", "intent://x", "https://", ""]:
            with self.assertRaises(ValidationError):
                validate_url(bad)
        self.assertEqual(normalize_phone("+91 98765-43210"), "919876543210")
        for bad in ["", "abc", "0123456789", "123"]:
            with self.assertRaises(ValidationError):
                normalize_phone(bad)

    def test_formats(self):
        validate_json('{"a":1}')
        validate_xml("<a><b/></a>")
        with self.assertRaises(ValidationError):
            validate_json("{bad")
        with self.assertRaises(ValidationError):
            validate_xml("<a>")


if __name__ == "__main__":
    unittest.main()
