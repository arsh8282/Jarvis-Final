import tempfile
import unittest
from pathlib import Path

from editor import diff
from editor.text_actions import ChangeReview, TextDocument, build_prompt, strip_fences
from editor.workspace import Workspace, WorkspaceError


class EditorTests(unittest.TestCase):
    def test_undo_redo_find_replace(self):
        d = TextDocument("one two one")
        self.assertEqual(d.find_all("ONE"), [0, 8])
        self.assertEqual(d.replace_all("one", "1"), 2)
        self.assertEqual(d.text, "1 two 1")
        self.assertTrue(d.undo())
        self.assertEqual(d.text, "one two one")
        self.assertTrue(d.redo())
        self.assertEqual(d.text, "1 two 1")
        self.assertFalse(TextDocument().undo())
        d.replace_range(0, 1, "uno")
        self.assertEqual(d.text, "uno two 1")
        with self.assertRaises(ValueError):
            d.replace_range(5, 99, "x")

    def test_selective_hunks(self):
        a = "l1\nl2\nl3\nl4\nl5\n"
        b = "L1\nl2\nl3\nl4\nL5\n"
        self.assertEqual(len(diff.hunks(a, b)), 2)
        self.assertEqual(diff.apply_hunks(a, b, {0}), "L1\nl2\nl3\nl4\nl5\n")
        self.assertEqual(diff.apply_hunks(a, b, {1}), "l1\nl2\nl3\nl4\nL5\n")
        self.assertEqual(diff.apply_hunks(a, b, {0, 1}), b)
        self.assertEqual(diff.apply_hunks(a, b, set()), a)
        self.assertIn("-l1", diff.unified(a, b))

    def test_change_review_preserves_original(self):
        r = ChangeReview("a\nb\n", "a\nB\n")
        self.assertEqual(r.original, "a\nb\n")
        self.assertEqual(r.hunk_count(), 1)
        self.assertEqual(r.result(), "a\nB\n")
        self.assertEqual(r.result([]), "a\nb\n")

    def test_prompts(self):
        self.assertIn("French", build_prompt("Translate", "hi", "French"))
        with self.assertRaises(ValueError):
            build_prompt("Hack", "x")
        self.assertEqual(strip_fences("```py\nprint(1)\n```"), "print(1)")
        self.assertEqual(strip_fences("plain"), "plain")


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.ws = Workspace(Path(tempfile.mkdtemp()) / "ws")

    def test_write_backup_restore(self):
        self.ws.write_text("a.txt", "v1")
        r = self.ws.write_text("a.txt", "v2")
        self.assertIsNotNone(r["backup"])
        self.assertEqual(self.ws.read_text("a.txt"), "v2")
        backups = self.ws.list_backups("a.txt")
        self.assertEqual(len(backups), 1)
        self.ws.restore("a.txt", backups[0])
        self.assertEqual(self.ws.read_text("a.txt"), "v1")
        self.assertEqual(len(self.ws.list_backups("a.txt")), 2)  # restore kept the v2 copy too

    def test_no_silent_overwrite_and_traversal(self):
        self.ws.write_text("a.txt", "x")
        with self.assertRaises(WorkspaceError):
            self.ws.write_text("a.txt", "y", overwrite=False)
        for bad in ["../evil", "/abs", ".jarvis_backups/x.bak"]:
            with self.assertRaises(WorkspaceError):
                self.ws.write_text(bad, "z")

    def test_rename_delete_search_list(self):
        self.ws.write_text("d/a.py", "print('needle')\n")
        self.assertEqual(self.ws.rename("d/a.py", "d/b.py"), "d/b.py")
        self.ws.write_text("c.txt", "c")
        with self.assertRaises(WorkspaceError):
            self.ws.rename("d/b.py", "c.txt")
        self.assertEqual(self.ws.search("NEEDLE")[0]["path"], "d/b.py")
        self.assertNotIn(".jarvis_backups", [e["name"] for e in self.ws.list_dir("")])
        self.ws.delete("c.txt")
        self.assertFalse((self.ws.root / "c.txt").exists())
        self.assertEqual(len(self.ws.list_backups("c.txt")), 1)

    def test_large_binary_and_missing(self):
        (self.ws.root / "big.txt").write_text("x" * (Workspace.MAX_READ + 1))
        (self.ws.root / "bin.dat").write_bytes(b"\xff\xfe\x00\x80")
        for f in ["big.txt", "bin.dat", "nope.txt"]:
            with self.assertRaises(WorkspaceError, msg=f):
                self.ws.read_text(f)

    def test_read_only_file_reported(self):
        p = self.ws.root / "ro.txt"
        p.write_text("x")
        p.chmod(0o444)
        try:
            self.ws.write_text("ro.txt", "y")
            wrote = True
        except WorkspaceError:
            wrote = False
        p.chmod(0o644)
        if not wrote:
            self.assertEqual(p.read_text(), "x")  # error surfaced and file untouched


if __name__ == "__main__":
    unittest.main()
