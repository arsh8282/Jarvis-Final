from __future__ import annotations

import time
from typing import Callable

from .database import Database


class MemoryDisabled(Exception):
    pass


class MemoryStore:
    """Persistent memories. `enabled` is read live from settings; when off, nothing new is saved."""

    def __init__(self, db: Database, enabled: Callable[[], bool]):
        self.db, self.enabled = db, enabled

    def add(self, content: str) -> int:
        if not self.enabled():
            raise MemoryDisabled("Memory is disabled; nothing was saved.")
        content = content.strip()
        if not content:
            raise ValueError("Memory cannot be empty.")
        return self.db.execute("INSERT INTO memories(content,created) VALUES(?,?)", (content[:1000], time.time())).lastrowid

    def list(self) -> list[dict]:
        return [dict(r) for r in self.db.query("SELECT id,content,created FROM memories ORDER BY id")]

    def update(self, mem_id: int, content: str) -> None:
        if not content.strip():
            raise ValueError("Memory cannot be empty.")
        self.db.execute("UPDATE memories SET content=? WHERE id=?", (content.strip()[:1000], mem_id))

    def delete(self, mem_id: int) -> None:
        self.db.execute("DELETE FROM memories WHERE id=?", (mem_id,))

    def clear(self) -> None:
        self.db.execute("DELETE FROM memories")

    def active_texts(self) -> list[str]:
        """Memories injected into prompts: only when enabled."""
        return [m["content"] for m in self.list()] if self.enabled() else []
