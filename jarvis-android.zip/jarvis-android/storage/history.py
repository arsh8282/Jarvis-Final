from __future__ import annotations

import json
import time
from typing import Optional

from .database import Database


class HistoryStore:
    def __init__(self, db: Database):
        self.db = db

    def create(self, title: str = "New conversation") -> int:
        now = time.time()
        return self.db.execute("INSERT INTO conversations(title,created,updated) VALUES(?,?,?)",
                               (title, now, now)).lastrowid

    def add_message(self, conv_id: int, role: str, content: str) -> int:
        now = time.time()
        cur = self.db.execute("INSERT INTO messages(conversation_id,role,content,created) VALUES(?,?,?,?)",
                              (conv_id, role, content, now))
        self.db.execute("UPDATE conversations SET updated=? WHERE id=?", (now, conv_id))
        return cur.lastrowid

    def messages(self, conv_id: int) -> list[dict]:
        return [dict(r) for r in self.db.query(
            "SELECT id,role,content,created FROM messages WHERE conversation_id=? ORDER BY id", (conv_id,))]

    def delete_last(self, conv_id: int, role: str) -> None:
        self.db.execute("DELETE FROM messages WHERE id=(SELECT MAX(id) FROM messages WHERE conversation_id=? AND role=?)",
                        (conv_id, role))

    def list(self, query: str = "") -> list[dict]:
        if query.strip():
            like = f"%{query.strip()}%"
            rows = self.db.query(
                "SELECT DISTINCT c.id,c.title,c.updated FROM conversations c LEFT JOIN messages m ON m.conversation_id=c.id "
                "WHERE c.title LIKE ? OR m.content LIKE ? ORDER BY c.updated DESC", (like, like))
        else:
            rows = self.db.query("SELECT id,title,updated FROM conversations ORDER BY updated DESC")
        return [dict(r) for r in rows]

    def title(self, conv_id: int) -> Optional[str]:
        r = self.db.query("SELECT title FROM conversations WHERE id=?", (conv_id,))
        return r[0]["title"] if r else None

    def rename(self, conv_id: int, title: str) -> None:
        title = title.strip()
        if not title:
            raise ValueError("Title cannot be empty.")
        self.db.execute("UPDATE conversations SET title=? WHERE id=?", (title[:120], conv_id))

    def delete(self, conv_id: int) -> None:
        self.db.execute("DELETE FROM conversations WHERE id=?", (conv_id,))

    def clear_all(self) -> None:
        self.db.execute("DELETE FROM conversations")

    def export_json(self, conv_id: Optional[int] = None) -> str:
        ids = [conv_id] if conv_id else [c["id"] for c in self.list()]
        return json.dumps([{"id": i, "title": self.title(i), "messages": self.messages(i)} for i in ids],
                          indent=2, ensure_ascii=False)

    def export_markdown(self, conv_id: int) -> str:
        out = [f"# {self.title(conv_id)}", ""]
        for m in self.messages(conv_id):
            out += [f"**{m['role'].capitalize()}:**", "", m["content"], ""]
        return "\n".join(out)
