"""Google Gemini provider (REST, generativelanguage.googleapis.com). Uses stdlib urllib only."""
from __future__ import annotations

import json
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request
from typing import Callable, Iterator, Optional, Sequence

from .base import Cancelled, ChatMessage, GenerationConfig, Provider, ProviderError

BASE_URL = "https://generativelanguage.googleapis.com/v1beta"


class UrllibTransport:
    """Real HTTP transport. Tests inject a fake with the same two methods."""

    def __init__(self) -> None:
        try:
            import certifi  # bundled in the APK via requirements
            self._ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            self._ctx = ssl.create_default_context()

    def _open(self, method, url, headers, body, timeout):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            return urllib.request.urlopen(req, timeout=timeout, context=self._ctx), None
        except urllib.error.HTTPError as e:
            return None, e
        except (urllib.error.URLError, socket.timeout, OSError) as e:
            raise ProviderError("network", "Network error: could not reach the AI service.", retryable=True) from e

    def request(self, method, url, headers, body, timeout=60.0):
        resp, err = self._open(method, url, headers, body, timeout)
        if err is not None:
            return err.code, err.read().decode("utf-8", "replace")
        with resp:
            return resp.status, resp.read().decode("utf-8", "replace")

    def stream_lines(self, method, url, headers, body, timeout=60.0):
        resp, err = self._open(method, url, headers, body, timeout)
        if err is not None:
            return err.code, iter([err.read().decode("utf-8", "replace")])

        def gen():
            with resp:
                for raw in resp:
                    yield raw.decode("utf-8", "replace").rstrip("\r\n")
        return resp.status, gen()


def map_error(status: int, body: str) -> ProviderError:
    msg = ""
    try:
        msg = json.loads(body).get("error", {}).get("message", "")
    except Exception:
        pass
    low = (msg + body[:300]).lower()
    if status in (401, 403) or "api key not valid" in low or "api_key_invalid" in low:
        return ProviderError("auth", "The API key was rejected. Check it in Provider settings.", False, status)
    if status == 404:
        return ProviderError("model_not_found", "Model not found or unavailable for this key.", False, status)
    if status == 429:
        return ProviderError("rate_limit", "Rate limit or quota reached. Wait and try again.", True, status)
    if status >= 500:
        return ProviderError("server", "The AI service had a temporary error.", True, status)
    if status == 400:
        return ProviderError("bad_request", f"Request rejected: {msg[:200] or 'invalid request'}", False, status)
    return ProviderError("unknown", f"Unexpected response (HTTP {status}).", False, status)


class GeminiProvider(Provider):
    name = "gemini"

    def __init__(self, api_key: str, model: str = "gemini-2.5-flash", transport=None,
                 max_retries: int = 2, sleep: Callable[[float], None] = time.sleep, timeout: float = 60.0):
        self._api_key, self.model = api_key, model
        self.transport = transport or UrllibTransport()
        self.max_retries, self._sleep, self.timeout = max_retries, sleep, timeout

    # ---- request construction (pure; unit-tested) ----
    def _headers(self) -> dict:
        return {"Content-Type": "application/json", "x-goog-api-key": self._api_key}  # key never put in URL

    def build_request(self, messages: Sequence[ChatMessage], system: str, config: GenerationConfig) -> dict:
        body: dict = {
            "contents": [{"role": "model" if m.role == "assistant" else "user", "parts": [{"text": m.content}]}
                         for m in messages],
            "generationConfig": {"temperature": config.temperature, "maxOutputTokens": config.max_output_tokens},
        }
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        return body

    @staticmethod
    def parse_response(data: dict) -> str:
        block = (data.get("promptFeedback") or {}).get("blockReason")
        if block:
            raise ProviderError("blocked", f"The request was blocked by the provider ({block}).")
        cands = data.get("candidates") or []
        if not cands:
            raise ProviderError("unknown", "The provider returned no answer.")
        parts = (cands[0].get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts)
        if not text and cands[0].get("finishReason") not in (None, "STOP", "MAX_TOKENS"):
            raise ProviderError("blocked", f"No text returned (finish reason: {cands[0].get('finishReason')}).")
        return text

    def _check_key(self):
        if not self._api_key:
            raise ProviderError("auth", "No API key set. Add one in Provider settings.")

    def _with_retry(self, fn):
        attempt = 0
        while True:
            try:
                return fn()
            except ProviderError as e:
                if not e.retryable or attempt >= self.max_retries:
                    raise
                self._sleep(min(2 ** attempt, 8))
                attempt += 1

    # ---- API ----
    def generate(self, messages, system, config) -> str:
        self._check_key()
        url = f"{BASE_URL}/models/{self.model}:generateContent"
        body = self.build_request(messages, system, config)

        def call():
            status, text = self.transport.request("POST", url, self._headers(), body, self.timeout)
            if status != 200:
                raise map_error(status, text)
            data = json.loads(text)
            self.last_usage = data.get("usageMetadata")
            return self.parse_response(data)
        return self._with_retry(call)

    def stream(self, messages, system, config, cancel: Optional[threading.Event] = None) -> Iterator[str]:
        self._check_key()
        url = f"{BASE_URL}/models/{self.model}:streamGenerateContent?alt=sse"
        body = self.build_request(messages, system, config)
        # Retry only before any chunk is delivered; never replay a partially shown answer.
        status, lines = self._with_retry(lambda: self._open_stream(url, body))
        for line in lines:
            if cancel is not None and cancel.is_set():
                raise Cancelled()
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if not payload or payload == "[DONE]":
                continue
            data = json.loads(payload)
            if data.get("usageMetadata"):
                self.last_usage = data["usageMetadata"]
            text = self.parse_response(data) if (data.get("candidates") or data.get("promptFeedback")) else ""
            if text:
                yield text

    def _open_stream(self, url, body):
        status, lines = self.transport.stream_lines("POST", url, self._headers(), body, self.timeout)
        if status != 200:
            raise map_error(status, "".join(lines))
        return status, lines

    def list_models(self) -> list[str]:
        self._check_key()
        status, text = self._with_retry(lambda: self._get(f"{BASE_URL}/models?pageSize=100"))
        out = []
        for m in json.loads(text).get("models", []):
            if "generateContent" in m.get("supportedGenerationMethods", []):
                out.append(m["name"].split("/", 1)[-1])
        return out

    def _get(self, url):
        status, text = self.transport.request("GET", url, self._headers(), None, self.timeout)
        if status != 200:
            raise map_error(status, text)
        return status, text
