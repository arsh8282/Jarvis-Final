"""Offline demo provider: works without network or API key (used by UI demo and tests)."""
from __future__ import annotations

import threading
from typing import Iterator, Optional, Sequence

from .base import Cancelled, ChatMessage, GenerationConfig, Provider, ProviderError


class MockProvider(Provider):
    name = "mock"

    def __init__(self, model: str = "mock-1"):
        self.model = model
        self.calls: list[dict] = []

    def _reply(self, messages: Sequence[ChatMessage]) -> str:
        last = next((m.content for m in reversed(messages) if m.role == "user"), "")
        if "/fail" in last:
            raise ProviderError("server", "Mock provider simulated failure.", retryable=True, status=503)
        return f"[Demo mode - no AI provider configured] You said: {last}"

    def generate(self, messages, system, config: GenerationConfig) -> str:
        self.calls.append({"messages": list(messages), "system": system, "config": config})
        return self._reply(messages)

    def stream(self, messages, system, config, cancel: Optional[threading.Event] = None) -> Iterator[str]:
        text = self.generate(messages, system, config)
        for word in text.split(" "):
            if cancel is not None and cancel.is_set():
                raise Cancelled()
            yield word + " "

    def list_models(self) -> list[str]:
        return ["mock-1"]

    def test_connection(self) -> str:
        return "Mock provider is always available (no network used)."
