from .base import Cancelled, ChatMessage, GenerationConfig, Provider, ProviderError
from .gemini import GeminiProvider
from .mock import MockProvider

__all__ = ["Cancelled", "ChatMessage", "GenerationConfig", "Provider", "ProviderError",
           "GeminiProvider", "MockProvider", "create_provider"]


def create_provider(name: str, api_key: str = "", model: str = ""):
    """Factory: register new providers here (see README 'Adding a provider')."""
    if name == "gemini":
        return GeminiProvider(api_key, model or "gemini-2.5-flash")
    return MockProvider()
