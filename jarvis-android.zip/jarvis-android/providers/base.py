"""Provider abstraction. All provider-specific behaviour lives behind this interface."""
from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Iterator, Optional, Sequence


@dataclass(frozen=True)
class ChatMessage:
    role: str  # "user" | "assistant"
    content: str


@dataclass
class GenerationConfig:
    temperature: float = 0.7
    max_output_tokens: int = 2048


class ProviderError(Exception):
    """kind: auth | rate_limit | model_not_found | network | blocked | bad_request | server | unsupported | unknown"""

    def __init__(self, kind: str, message: str, retryable: bool = False, status: Optional[int] = None):
        super().__init__(message)
        self.kind, self.message, self.retryable, self.status = kind, message, retryable, status


class Cancelled(Exception):
    """Raised when the user cancels an in-flight request."""


class Provider(ABC):
    name = "base"
    last_usage: Optional[dict] = None  # only set when the API supplies it

    @abstractmethod
    def generate(self, messages: Sequence[ChatMessage], system: str, config: GenerationConfig) -> str: ...

    @abstractmethod
    def stream(self, messages: Sequence[ChatMessage], system: str, config: GenerationConfig,
               cancel: Optional[threading.Event] = None) -> Iterator[str]: ...

    def list_models(self) -> list[str]:
        raise ProviderError("unsupported", "This provider cannot list models; enter a model id manually.")

    def test_connection(self) -> str:
        out = self.generate([ChatMessage("user", "Reply with the single word: ready")], "", GenerationConfig(0.0, 16))
        return out.strip()[:80] or "(empty reply)"
